import { PlayerScoreRecord } from '../types/game';

const STORAGE_KEY = 'voxel_lib_leaderboard_v1';
const WEBHOOK_KEY = 'voxel_lib_gsheet_webhook_url';

export function getScoreRecords(): PlayerScoreRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveScoreRecord(record: PlayerScoreRecord): PlayerScoreRecord[] {
  const existing = getScoreRecords();
  const updated = [record, ...existing];
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Could not save to localStorage', err);
  }

  // Attempt webhook sync if configured
  const webhookUrl = getCustomWebhookUrl();
  if (webhookUrl) {
    sendToGoogleSheetWebhook(webhookUrl, record).catch(() => {});
  }

  return updated;
}

export function clearScoreRecords(): void {
  localStorage.removeItem(STORAGE_KEY);
}

export function getCustomWebhookUrl(): string {
  return localStorage.getItem(WEBHOOK_KEY) || '';
}

export function setCustomWebhookUrl(url: string): void {
  if (url.trim()) {
    localStorage.setItem(WEBHOOK_KEY, url.trim());
  } else {
    localStorage.removeItem(WEBHOOK_KEY);
  }
}

export async function sendToGoogleSheetWebhook(webhookUrl: string, record: PlayerScoreRecord): Promise<boolean> {
  try {
    const payload = {
      nama: record.playerName,
      skor: `${record.score}/${record.totalQuestions}`,
      peratus: `${record.percentage}%`,
      masaSaat: record.durationSeconds,
      tarikh: record.completedAt,
      jawapan: record.answers.map((a, i) => `S${i+1}: ${a.isCorrect ? 'BETUL' : 'SALAH'} (${a.selectedOption})`).join(' | ')
    };

    // Google Apps Script Webhook accepts POST
    await fetch(webhookUrl, {
      method: 'POST',
      mode: 'no-cors',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });
    return true;
  } catch (err) {
    console.error('Error sending to webhook', err);
    return false;
  }
}

export function downloadCSV(records: PlayerScoreRecord[]): void {
  if (records.length === 0) return;

  const headers = [
    'Bil',
    'Nama Murid / Peserta',
    'Skor',
    'Jumlah Soalan',
    'Peratus (%)',
    'Tempoh (Saat)',
    'Tarikh & Waktu',
    'S1 Maksud Vernakular',
    'S2 Sektor Sekolah Tamil',
    'S3 Bahasa Pengantar Inggeris',
    'S4 Ciri Sekolah Melayu',
    'S5 Sekolah Inggeris Bandar',
    'S6 Sistem Seragam Sebelum Merdeka'
  ];

  const rows = records.map((r, idx) => {
    const answerColumns = [1, 2, 3, 4, 5, 6].map(qId => {
      const ans = r.answers.find(a => a.questionId === qId);
      if (!ans) return 'Belum Jawab';
      return ans.isCorrect ? 'BETUL' : 'SALAH';
    });

    return [
      idx + 1,
      `"${r.playerName.replace(/"/g, '""')}"`,
      r.score,
      r.totalQuestions,
      `${r.percentage}%`,
      r.durationSeconds,
      `"${r.completedAt}"`,
      ...answerColumns
    ].join(',');
  });

  const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Tanah_Melayu_Pendidikan_Skor_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function copyTSVForSheets(records: PlayerScoreRecord[]): Promise<boolean> {
  const headers = [
    'Bil',
    'Nama Peserta',
    'Skor',
    'Peratus (%)',
    'Masa (Saat)',
    'Tarikh',
    'Keputusan Soalan (1-6)'
  ];

  const rows = records.map((r, idx) => {
    const ansSummary = r.answers.map((a, i) => `S${i+1}:${a.isCorrect ? '✅' : '❌'}`).join(' ');
    return [
      idx + 1,
      r.playerName,
      `${r.score}/${r.totalQuestions}`,
      `${r.percentage}%`,
      `${r.durationSeconds}s`,
      r.completedAt,
      ansSummary
    ].join('\t');
  });

  const text = [headers.join('\t'), ...rows].join('\n');
  return navigator.clipboard.writeText(text).then(() => true).catch(() => false);
}
