import React, { useState, useRef } from 'react';
import { GameCanvas } from './game3d/GameCanvas';
import { NameEntryScreen } from './components/NameEntryScreen';
import { QuizModal } from './components/QuizModal';
import { GameOverScreen } from './components/GameOverScreen';
import { LeaderboardModal } from './components/LeaderboardModal';
import { GameHUD } from './components/GameHUD';
import { VirtualJoystick } from './components/VirtualJoystick';
import { QuizQuestion, QuizAnswerRecord, PlayerScoreRecord, GamePhase } from './types/game';
import { QUIZ_QUESTIONS } from './data/quizData';
import { saveScoreRecord } from './utils/sheetsSync';

export default function App() {
  const [gamePhase, setGamePhase] = useState<GamePhase>('name_entry');
  const [playerName, setPlayerName] = useState<string>('');
  const [completedQuestionIds, setCompletedQuestionIds] = useState<number[]>([]);
  const [answers, setAnswers] = useState<QuizAnswerRecord[]>([]);
  const [activeQuestion, setActiveQuestion] = useState<QuizQuestion | null>(null);
  const [nearQuestion, setNearQuestion] = useState<QuizQuestion | null>(null);
  const [isNearCompleted, setIsNearCompleted] = useState<boolean>(false);
  const [showLeaderboard, setShowLeaderboard] = useState<boolean>(false);
  const [finalRecord, setFinalRecord] = useState<PlayerScoreRecord | null>(null);

  // Joystick & Interaction bridge
  const [joystickVector, setJoystickVector] = useState({ x: 0, y: 0 });
  const [interactRequested, setInteractRequested] = useState(false);

  // Track start time
  const startTimeRef = useRef<number>(Date.now());

  // Start exploration from name entry screen
  const handleStartGame = (name: string) => {
    setPlayerName(name);
    setCompletedQuestionIds([]);
    setAnswers([]);
    setActiveQuestion(null);
    setFinalRecord(null);
    startTimeRef.current = Date.now();
    setGamePhase('exploring');
  };

  // Triggered when character approaches or leaves an object
  const handleNearObject = (question: QuizQuestion | null, isCompleted: boolean) => {
    setNearQuestion(question);
    setIsNearCompleted(isCompleted);
  };

  // Triggered when player presses [E] or clicks interact
  const handleTriggerInteract = (question: QuizQuestion) => {
    if (completedQuestionIds.includes(question.id)) {
      // Already answered - can either re-inspect or alert
      setActiveQuestion(question);
      setGamePhase('quiz_modal');
      return;
    }
    setActiveQuestion(question);
    setGamePhase('quiz_modal');
  };

  // When player answers a question in QuizModal
  const handleAnswerSubmit = (record: QuizAnswerRecord) => {
    const updatedAnswers = [...answers.filter(a => a.questionId !== record.questionId), record];
    const updatedCompletedIds = Array.from(new Set([...completedQuestionIds, record.questionId]));

    setAnswers(updatedAnswers);
    setCompletedQuestionIds(updatedCompletedIds);
    setActiveQuestion(null);

    // Check if all 6 questions have been answered
    if (updatedCompletedIds.length >= QUIZ_QUESTIONS.length) {
      const durationSec = Math.max(1, Math.round((Date.now() - startTimeRef.current) / 1000));
      const score = updatedAnswers.filter(a => a.isCorrect).length;
      const total = QUIZ_QUESTIONS.length;
      const percentage = Math.round((score / total) * 100);

      const newRecord: PlayerScoreRecord = {
        id: 'rec_' + Date.now(),
        playerName,
        score,
        totalQuestions: total,
        percentage,
        completedAt: new Date().toLocaleString('ms-MY', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        durationSeconds: durationSec,
        answers: updatedAnswers
      };

      // Save to local storage & trigger webhook sync
      saveScoreRecord(newRecord);
      setFinalRecord(newRecord);
      setGamePhase('game_over');
    } else {
      setGamePhase('exploring');
    }
  };

  const handleRestart = () => {
    setGamePhase('name_entry');
    setCompletedQuestionIds([]);
    setAnswers([]);
    setActiveQuestion(null);
    setFinalRecord(null);
  };

  const currentQuestionIdx = activeQuestion
    ? QUIZ_QUESTIONS.findIndex(q => q.id === activeQuestion.id) + 1
    : 1;

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-stone-950 font-sans select-none">
      {/* 3D WebGL Canvas Viewport */}
      <GameCanvas
        completedQuestionIds={completedQuestionIds}
        activeQuestion={activeQuestion}
        onNearObject={handleNearObject}
        onTriggerInteract={handleTriggerInteract}
        joystickVector={joystickVector}
        interactRequested={interactRequested}
        onInteractHandled={() => setInteractRequested(false)}
      />

      {/* In-Game Heads Up Display (HUD) */}
      {gamePhase === 'exploring' && (
        <>
          <GameHUD
            playerName={playerName}
            completedQuestionIds={completedQuestionIds}
            nearQuestion={nearQuestion}
            isNearCompleted={isNearCompleted}
            onInteract={() => {
              if (nearQuestion) handleTriggerInteract(nearQuestion);
            }}
            onOpenLeaderboard={() => setShowLeaderboard(true)}
          />

          {/* Virtual Joystick for touch / mobile screens */}
          <VirtualJoystick
            onVectorChange={setJoystickVector}
            onInteract={() => setInteractRequested(true)}
            isNearObject={!!nearQuestion}
            nearObjectName={nearQuestion?.objectName || ''}
          />
        </>
      )}

      {/* Name Entry Screen at Start */}
      {gamePhase === 'name_entry' && (
        <NameEntryScreen
          onStartGame={handleStartGame}
          onOpenLeaderboard={() => setShowLeaderboard(true)}
        />
      )}

      {/* Quiz Modal when interacting with an object */}
      {gamePhase === 'quiz_modal' && activeQuestion && (
        <QuizModal
          question={activeQuestion}
          questionNumber={currentQuestionIdx}
          totalQuestions={QUIZ_QUESTIONS.length}
          onAnswerSubmit={handleAnswerSubmit}
          onClose={() => {
            setActiveQuestion(null);
            setGamePhase('exploring');
          }}
        />
      )}

      {/* Game Over & Flashback Summary Screen */}
      {gamePhase === 'game_over' && finalRecord && (
        <GameOverScreen
          record={finalRecord}
          onRestart={handleRestart}
          onOpenLeaderboard={() => setShowLeaderboard(true)}
        />
      )}

      {/* Leaderboard & Sheet Manager Modal */}
      {showLeaderboard && (
        <LeaderboardModal onClose={() => setShowLeaderboard(false)} />
      )}
    </main>
  );
}
