export interface QuizQuestion {
  id: number;
  objectId: string;
  objectName: string;
  objectIcon: string;
  category: string;
  zoneName: string; // 'Zon Kampung Melayu' | 'Zon Estet Getah' | 'Zon Bandar Kolonial'
  question: string;
  options: string[];
  correctIndex: number;
  validCorrectIndices?: number[]; // For questions with multiple valid historical traits
  explanationCorrect: string;
  explanationWrong: string;
  worldPosition: [number, number, number]; // [x, y, z] in the 3D world
  description: string;
}

export interface QuizAnswerRecord {
  questionId: number;
  objectId: string;
  objectName: string;
  zoneName: string;
  questionText: string;
  selectedOption: string;
  selectedIndex: number;
  correctOption: string;
  correctIndex: number;
  isCorrect: boolean;
  explanation: string;
  answeredAt: string;
}

export interface PlayerScoreRecord {
  id: string;
  playerName: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  completedAt: string;
  durationSeconds: number;
  answers: QuizAnswerRecord[];
}

export type GamePhase = 'name_entry' | 'exploring' | 'quiz_modal' | 'game_over';
