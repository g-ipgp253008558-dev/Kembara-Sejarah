import React, { useRef, useState, useEffect } from 'react';

interface VirtualJoystickProps {
  onVectorChange: (vec: { x: number; y: number }) => void;
  onInteract: () => void;
  isNearObject: boolean;
  nearObjectName: string;
}

export const VirtualJoystick: React.FC<VirtualJoystickProps> = ({
  onVectorChange,
  onInteract,
  isNearObject,
  nearObjectName
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const [touchActive, setTouchActive] = useState(false);
  const touchIdRef = useRef<number | null>(null);
  const centerRef = useRef({ x: 0, y: 0 });

  const radius = 50; // max distance from center

  const handleTouchStart = (e: React.TouchEvent) => {
    if (touchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    touchIdRef.current = touch.identifier;

    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    centerRef.current = {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2
    };

    updatePosition(touch.clientX, touch.clientY);
    setTouchActive(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier === touchIdRef.current) {
        updatePosition(t.clientX, t.clientY);
        break;
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchIdRef.current) {
        touchIdRef.current = null;
        setKnobPos({ x: 0, y: 0 });
        setTouchActive(false);
        onVectorChange({ x: 0, y: 0 });
        break;
      }
    }
  };

  const updatePosition = (clientX: number, clientY: number) => {
    const dx = clientX - centerRef.current.x;
    const dy = clientY - centerRef.current.y;
    const dist = Math.hypot(dx, dy);

    let normX = 0;
    let normY = 0;

    if (dist > 0) {
      const clampedDist = Math.min(dist, radius);
      const angle = Math.atan2(dy, dx);
      const kx = Math.cos(angle) * clampedDist;
      const ky = Math.sin(angle) * clampedDist;
      setKnobPos({ x: kx, y: ky });

      normX = kx / radius;
      normY = ky / radius;
    } else {
      setKnobPos({ x: 0, y: 0 });
    }

    onVectorChange({ x: normX, y: normY });
  };

  return (
    <div className="absolute inset-x-0 bottom-3 px-4 z-20 pointer-events-none flex items-end justify-between select-none">
      {/* Left Virtual Joystick */}
      <div className="pointer-events-auto">
        <div
          ref={containerRef}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onTouchCancel={handleTouchEnd}
          className="w-28 h-28 rounded-full bg-stone-950/60 border-2 border-stone-700/80 shadow-lg relative flex items-center justify-center touch-none backdrop-blur-xs"
        >
          {/* Base Inner Ring */}
          <div className="w-14 h-14 rounded-full border border-dashed border-stone-600/70 pointer-events-none" />

          {/* Draggable Knob */}
          <div
            className={`w-12 h-12 rounded-full absolute transition-transform ease-out pointer-events-none border-2 shadow-md ${
              touchActive
                ? 'bg-amber-500 border-amber-300 scale-105'
                : 'bg-stone-800/90 border-stone-600'
            }`}
            style={{
              transform: `translate(${knobPos.x}px, ${knobPos.y}px)`
            }}
          />
        </div>
        <div className="text-[10px] text-stone-400 font-mono text-center mt-1">
          Gerak Watak
        </div>
      </div>

      {/* Right Interaction Button */}
      <div className="pointer-events-auto flex flex-col items-end gap-2">
        {isNearObject && (
          <div className="text-[11px] font-mono text-amber-300 bg-stone-950/80 px-2 py-1 rounded border border-amber-600/60 animate-bounce">
            Dekat: {nearObjectName}
          </div>
        )}

        <button
          type="button"
          onClick={onInteract}
          className={`h-16 px-5 rounded-xl border-2 font-bold font-mono text-sm shadow-xl cursor-pointer transition transform active:scale-95 flex items-center gap-2 ${
            isNearObject
              ? 'bg-gradient-to-r from-amber-600 to-amber-500 text-stone-950 border-amber-300 ring-4 ring-amber-500/40'
              : 'bg-stone-900/80 text-stone-400 border-stone-700 hover:text-stone-300'
          }`}
        >
          <span className="text-xl">🔍</span>
          <div className="text-left">
            <div className="text-xs uppercase font-extrabold leading-none">
              {isNearObject ? 'Buka Kuiz' : 'Interaksi'}
            </div>
            <div className="text-[10px] opacity-80 leading-tight">
              [E] / [Spes]
            </div>
          </div>
        </button>
      </div>
    </div>
  );
};
