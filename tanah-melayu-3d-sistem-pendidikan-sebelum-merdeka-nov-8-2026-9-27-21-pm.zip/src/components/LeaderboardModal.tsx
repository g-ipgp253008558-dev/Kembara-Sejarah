import React, { useState } from 'react';
import { PlayerScoreRecord } from '../types/game';
import { getScoreRecords, downloadCSV, copyTSVForSheets, clearScoreRecords, getCustomWebhookUrl, setCustomWebhookUrl } from '../utils/sheetsSync';
import { soundManager } from '../utils/audio';

interface LeaderboardModalProps {
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({ onClose }) => {
  const [records, setRecords] = useState<PlayerScoreRecord[]>(getScoreRecords());
  const [search, setSearch] = useState('');
  const [copied, setCopied] = useState(false);
  const [showWebhookGuide, setShowWebhookGuide] = useState(false);
  const [webhookInput, setWebhookInput] = useState(getCustomWebhookUrl());
  const [savedWebhookMsg, setSavedWebhookMsg] = useState(false);

  const filtered = records.filter(r =>
    r.playerName.toLowerCase().includes(search.toLowerCase())
  );

  const handleDownload = () => {
    soundManager.playClick();
    downloadCSV(records);
  };

  const handleCopy = async () => {
    soundManager.playClick();
    const ok = await copyTSVForSheets(records);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleClear = () => {
    if (window.confirm('Adakah anda pasti ingin memadam semua rekod papan skor ini?')) {
      clearScoreRecords();
      setRecords([]);
      soundManager.playClick();
    }
  };

  const handleSaveWebhook = (e: React.FormEvent) => {
    e.preventDefault();
    setCustomWebhookUrl(webhookInput);
    setSavedWebhookMsg(true);
    soundManager.playClick();
    setTimeout(() => setSavedWebhookMsg(false), 2500);
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-stone-950/85 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-4xl bg-stone-900 border-4 border-amber-800 rounded-lg shadow-2xl p-5 sm:p-7 text-stone-100 max-h-[92vh] flex flex-col">
        {/* Minecraft Corner Studs */}
        <div className="absolute -top-2 -left-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -bottom-2 -right-2 w-4 h-4 bg-amber-500 border border-amber-950" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-amber-800/60 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl p-1.5 bg-amber-950 border border-amber-700/60 rounded">
              🏆
            </span>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-amber-200 font-mono">
                PAPAN SKOR & REKOD PESERTA
              </h2>
              <p className="text-xs text-stone-400">
                Senarai rekod murid/peserta yang telah menjawab kuiz Sistem Pendidikan Sebelum Merdeka
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded bg-stone-800 hover:bg-stone-700 border border-stone-600 flex items-center justify-center text-stone-300 font-bold text-base cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Toolbar & Search */}
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between mb-4">
          <input
            type="text"
            placeholder="Cari nama peserta..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="px-3 py-2 bg-stone-950 border border-stone-700 rounded text-sm text-stone-200 focus:outline-hidden focus:border-amber-400 w-full sm:w-64"
          />

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleDownload}
              disabled={records.length === 0}
              className="px-3 py-2 bg-stone-800 hover:bg-stone-700 disabled:opacity-50 text-stone-200 text-xs font-semibold rounded border border-stone-600 transition flex items-center gap-1.5 cursor-pointer"
            >
              <span>📥 CSV</span>
            </button>

            <button
              type="button"
              onClick={handleCopy}
              disabled={records.length === 0}
              className="px-3 py-2 bg-amber-950/60 hover:bg-amber-900/80 disabled:opacity-50 text-amber-300 text-xs font-semibold rounded border border-amber-700/60 transition flex items-center gap-1.5 cursor-pointer"
            >
              <span>{copied ? '✅ Disalin!' : '📋 Salin Google Sheets'}</span>
            </button>

            <button
              type="button"
              onClick={() => setShowWebhookGuide(!showWebhookGuide)}
              className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold rounded border border-stone-600 transition flex items-center gap-1.5 cursor-pointer"
            >
              <span>🔗 Link Webhook Sheets</span>
            </button>

            {records.length > 0 && (
              <button
                type="button"
                onClick={handleClear}
                className="px-2.5 py-2 bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 text-xs font-semibold rounded border border-rose-800/60 transition cursor-pointer"
                title="Padam Semua Rekod"
              >
                🗑️
              </button>
            )}
          </div>
        </div>

        {/* Optional Webhook Configuration Tray */}
        {showWebhookGuide && (
          <div className="mb-4 p-3.5 bg-stone-950 border border-amber-900/60 rounded text-xs text-stone-300 space-y-2">
            <div className="font-bold text-amber-300 flex items-center gap-1.5">
              <span>🔗 Sambungan Automatik Google Sheets (Google Apps Script):</span>
            </div>
            <p className="text-stone-400">
              Anda boleh memasukkan URL Google Apps Script Web App untuk menghantar keputusan setiap pemain secara terus ke Google Sheet peribadi anda setiap kali kuiz selesai.
            </p>
            <form onSubmit={handleSaveWebhook} className="flex gap-2">
              <input
                type="url"
                placeholder="https://script.google.com/macros/s/.../exec"
                value={webhookInput}
                onChange={(e) => setWebhookInput(e.target.value)}
                className="flex-1 px-2.5 py-1.5 bg-stone-900 border border-stone-700 rounded text-xs text-amber-200 focus:outline-hidden focus:border-amber-400"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold rounded text-xs cursor-pointer"
              >
                Simpan URL
              </button>
            </form>
            {savedWebhookMsg && (
              <p className="text-emerald-400 font-mono text-[11px]">
                ✅ URL Webhook berjaya dikemas kini!
              </p>
            )}
          </div>
        )}

        {/* Records Table */}
        <div className="flex-1 overflow-y-auto border border-stone-800 rounded bg-stone-950/60">
          {filtered.length === 0 ? (
            <div className="p-8 text-center text-stone-500 text-sm">
              {search ? 'Tiada peserta sepadan dengan carian.' : 'Belum ada rekod peserta. Main sekarang untuk mendaftar skor pertama!'}
            </div>
          ) : (
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-stone-900/90 text-stone-300 border-b border-stone-800 sticky top-0">
                <tr>
                  <th className="p-2.5 font-mono">#</th>
                  <th className="p-2.5">Nama Peserta</th>
                  <th className="p-2.5 font-mono text-center">Skor</th>
                  <th className="p-2.5 font-mono text-center">Peratus</th>
                  <th className="p-2.5 font-mono text-center">Masa</th>
                  <th className="p-2.5">Tarikh</th>
                  <th className="p-2.5">Keputusan (1-6)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/60">
                {filtered.map((rec, idx) => (
                  <tr key={rec.id} className="hover:bg-stone-800/40">
                    <td className="p-2.5 font-mono text-stone-500">{idx + 1}</td>
                    <td className="p-2.5 font-semibold text-stone-200">{rec.playerName}</td>
                    <td className="p-2.5 font-mono text-center font-bold text-amber-300">
                      {rec.score}/{rec.totalQuestions}
                    </td>
                    <td className="p-2.5 font-mono text-center">
                      <span className={`px-1.5 py-0.5 rounded ${
                        rec.percentage >= 80 ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                        rec.percentage >= 50 ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}>
                        {rec.percentage}%
                      </span>
                    </td>
                    <td className="p-2.5 font-mono text-center text-stone-400">{rec.durationSeconds}s</td>
                    <td className="p-2.5 text-stone-400 text-[11px]">{rec.completedAt}</td>
                    <td className="p-2.5 font-mono text-xs">
                      {rec.answers.map((a, i) => (
                        <span key={i} title={`Soalan ${i+1}: ${a.isCorrect ? 'Betul' : 'Salah'}`}>
                          {a.isCorrect ? '🟩' : '🟥'}
                        </span>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-amber-800/60 pt-3 mt-4 flex items-center justify-between text-xs text-stone-400">
          <div>
            Jumlah Rekod: <span className="font-mono text-amber-300 font-bold">{records.length}</span> peserta
          </div>
          <button
            type="button"
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded font-semibold border border-stone-600 cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
