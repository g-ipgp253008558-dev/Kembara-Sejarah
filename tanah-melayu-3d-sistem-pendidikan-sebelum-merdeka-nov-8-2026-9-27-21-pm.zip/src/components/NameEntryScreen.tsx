import React, { useState } from 'react';
import { soundManager } from '../utils/audio';

interface NameEntryScreenProps {
  onStartGame: (name: string) => void;
  onOpenLeaderboard: () => void;
}

export const NameEntryScreen: React.FC<NameEntryScreenProps> = ({
  onStartGame,
  onOpenLeaderboard
}) => {
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError('Sila masukkan nama anda sebelum meneroka!');
      soundManager.playWrong();
      return;
    }
    soundManager.playClick();
    onStartGame(trimmed);
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-xl border-4 border-amber-800/80 bg-stone-900/95 shadow-2xl p-6 sm:p-8 text-stone-100 rounded-lg">
        {/* Minecraft Style Corner Rivets */}
        <div className="absolute -top-2 -left-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -bottom-2 -right-2 w-4 h-4 bg-amber-500 border border-amber-950" />

        {/* Title Lockup */}
        <div className="text-center mb-6">
          <div className="inline-block px-3 py-1 mb-2 bg-amber-950/80 border border-amber-600/60 rounded text-amber-400 text-xs font-mono tracking-widest uppercase">
            3D Voxel Minecraft • Era Kolonial British
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-amber-300 drop-shadow-[0_4px_10px_rgba(245,158,11,0.4)] tracking-wide font-mono">
            TANAH MELAYU 3D
          </h1>
          <p className="text-amber-100 font-semibold text-sm mt-1">
            Sistem Pendidikan Sebelum Merdeka
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 mt-2 text-[11px] text-stone-300 font-mono">
            <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-700/60 rounded text-emerald-300">🛖 Kampung Melayu</span>
            <span className="px-2 py-0.5 bg-amber-950 border border-amber-700/60 rounded text-amber-300">🌳 Estet Getah</span>
            <span className="px-2 py-0.5 bg-blue-950 border border-blue-700/60 rounded text-blue-300">🏛️ Bandar Kolonial</span>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="playerName" className="block text-xs uppercase tracking-wider text-amber-200 font-semibold mb-2">
              Nama Peserta / Murid:
            </label>
            <input
              id="playerName"
              type="text"
              autoFocus
              maxLength={30}
              placeholder="Contoh: Muhammad Adam / Cikgu Siti"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError('');
              }}
              className="w-full px-4 py-3 bg-stone-950 border-2 border-amber-700/70 rounded text-amber-100 placeholder-stone-500 text-base font-medium focus:outline-hidden focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
            />
            {error && <p className="text-rose-400 text-xs mt-1.5 font-medium">{error}</p>}
          </div>

          {/* Guide Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-stone-950/70 border border-stone-800 rounded text-xs text-stone-300">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-amber-900/40 border border-amber-700/50 rounded text-amber-300 font-mono">
                WASD / 🕹️
              </span>
              <span>Gerak Karakter</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-amber-900/40 border border-amber-700/50 rounded text-amber-300 font-mono">
                [E] / Tap
              </span>
              <span>Buka Kuiz</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-amber-900/40 border border-amber-700/50 rounded text-amber-300 font-mono">
                6 Objek
              </span>
              <span>Selesaikan Semua</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 py-3 px-6 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-stone-950 font-bold text-base rounded border border-amber-300 shadow-lg cursor-pointer transition transform active:scale-98 flex items-center justify-center gap-2"
            >
              <span>⚔️ Mula Meneroka</span>
              <span className="text-xs font-mono opacity-80">(Tekan Enter)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundManager.playClick();
                onOpenLeaderboard();
              }}
              className="py-3 px-4 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600 rounded text-sm font-semibold cursor-pointer transition flex items-center justify-center gap-1.5"
            >
              <span>🏆 Papan Skor</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
