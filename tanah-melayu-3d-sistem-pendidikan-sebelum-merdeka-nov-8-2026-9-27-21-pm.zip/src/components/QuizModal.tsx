import React, { useState, useEffect } from 'react';
import { QuizQuestion, QuizAnswerRecord } from '../types/game';
import { soundManager } from '../utils/audio';

interface QuizModalProps {
  question: QuizQuestion;
  questionNumber: number;
  totalQuestions: number;
  onAnswerSubmit: (record: QuizAnswerRecord) => void;
  onClose: () => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({
  question,
  questionNumber,
  totalQuestions,
  onAnswerSubmit,
  onClose
}) => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState<boolean>(false);
  const [startTime] = useState<number>(Date.now());

  const isIndexCorrect = (idx: number) => {
    if (question.validCorrectIndices && question.validCorrectIndices.length > 0) {
      return question.validCorrectIndices.includes(idx);
    }
    return idx === question.correctIndex;
  };

  const handleSelectOption = (index: number) => {
    if (hasSubmitted) return;

    setSelectedIndex(index);
    setHasSubmitted(true);
    const correct = isIndexCorrect(index);

    if (correct) {
      soundManager.playCorrect();
    } else {
      soundManager.playWrong();
    }
  };

  const handleContinue = () => {
    if (selectedIndex === null) return;
    soundManager.playClick();

    const correct = isIndexCorrect(selectedIndex);
    const record: QuizAnswerRecord = {
      questionId: question.id,
      objectId: question.objectId,
      objectName: question.objectName,
      zoneName: question.zoneName,
      questionText: question.question,
      selectedOption: question.options[selectedIndex],
      selectedIndex,
      correctOption: question.options[question.correctIndex],
      correctIndex: question.correctIndex,
      isCorrect: correct,
      explanation: correct ? question.explanationCorrect : question.explanationWrong,
      answeredAt: new Date().toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' })
    };

    onAnswerSubmit(record);
  };

  // Keyboard navigation support: A, B, C, D to pick, Space/Enter to continue
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (!hasSubmitted) {
        if (e.key === 'a' || e.key === 'A' || e.key === '1') handleSelectOption(0);
        else if (e.key === 'b' || e.key === 'B' || e.key === '2') handleSelectOption(1);
        else if (e.key === 'c' || e.key === 'C' || e.key === '3') handleSelectOption(2);
        else if (e.key === 'd' || e.key === 'D' || e.key === '4') handleSelectOption(3);
      } else {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleContinue();
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [hasSubmitted, selectedIndex]);

  const optionLetters = ['A', 'B', 'C', 'D'];

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-2xl bg-stone-900 border-4 border-amber-800 rounded-lg shadow-2xl p-5 sm:p-7 text-stone-100 flex flex-col max-h-[92vh] overflow-y-auto">
        {/* Minecraft Corner Studs */}
        <div className="absolute -top-2 -left-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -bottom-2 -right-2 w-4 h-4 bg-amber-500 border border-amber-950" />

        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-800/60 pb-3 mb-4">
          <div className="flex items-center gap-3">
            <span className="text-3xl p-2 bg-amber-950/70 border border-amber-700/60 rounded">
              {question.objectIcon}
            </span>
            <div>
              <div className="text-xs font-mono uppercase text-amber-400 font-semibold tracking-wider flex items-center gap-2">
                <span>Artifak {questionNumber} / {totalQuestions}</span>
                <span>•</span>
                <span className="text-amber-300 font-bold">{question.zoneName}</span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-amber-100">
                {question.objectName}
              </h2>
            </div>
          </div>
        </div>

        {/* Question Text */}
        <div className="mb-5 bg-stone-950/80 p-4 rounded border border-amber-900/60">
          <p className="text-base sm:text-lg font-medium text-stone-100 leading-relaxed">
            {question.question}
          </p>
        </div>

        {/* Multiple Choice Options */}
        <div className="space-y-2.5 mb-5">
          {question.options.map((opt, idx) => {
            let optionStyles = 'bg-stone-800/80 border-stone-700 hover:bg-stone-750 hover:border-amber-500 text-stone-200';
            const isThisOptionCorrect = isIndexCorrect(idx);

            if (hasSubmitted) {
              if (isThisOptionCorrect) {
                // Correct answer is highlighted in green
                optionStyles = 'bg-emerald-950/90 border-emerald-500 text-emerald-200 font-semibold ring-2 ring-emerald-500/50';
              } else if (idx === selectedIndex && !isThisOptionCorrect) {
                // Chosen wrong answer highlighted in red
                optionStyles = 'bg-rose-950/90 border-rose-600 text-rose-200 line-through opacity-90';
              } else {
                optionStyles = 'bg-stone-950/50 border-stone-800 text-stone-500 opacity-60';
              }
            }

            return (
              <button
                key={idx}
                type="button"
                disabled={hasSubmitted}
                onClick={() => handleSelectOption(idx)}
                className={`w-full text-left p-3.5 sm:p-4 rounded border-2 transition flex items-center gap-3 cursor-pointer disabled:cursor-default ${optionStyles}`}
              >
                <span className="w-8 h-8 rounded bg-stone-900/90 border border-current flex items-center justify-center font-mono font-bold text-sm shrink-0">
                  {optionLetters[idx] || (idx + 1)}
                </span>
                <span className="text-sm sm:text-base leading-snug flex-1">
                  {opt}
                </span>
                {hasSubmitted && isThisOptionCorrect && (
                  <span className="text-emerald-400 font-bold text-sm bg-emerald-950 px-2 py-0.5 rounded border border-emerald-600">
                    Betul ✅
                  </span>
                )}
                {hasSubmitted && idx === selectedIndex && !isThisOptionCorrect && (
                  <span className="text-rose-400 font-bold text-sm bg-rose-950 px-2 py-0.5 rounded border border-rose-600">
                    Pilihan Anda ❌
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Immediate Feedback Card */}
        {hasSubmitted && (
          <div
            className={`p-4 rounded border-2 mb-4 animate-in fade-in duration-200 ${
              isIndexCorrect(selectedIndex!)
                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-100'
                : 'bg-rose-950/80 border-rose-600 text-rose-100'
            }`}
          >
            <div className="flex items-center gap-2 font-bold text-base mb-1.5">
              <span>{isIndexCorrect(selectedIndex!) ? '🎉 TAHNIAH!' : '💡 MAKLUM BALAS SEJARAH:'}</span>
              <span className="text-sm font-normal opacity-90">
                {isIndexCorrect(selectedIndex!)
                  ? 'Jawapan anda tepat sekali!'
                  : 'Jawapan kurang tepat.'}
              </span>
            </div>
            <p className="text-sm leading-relaxed opacity-95">
              {isIndexCorrect(selectedIndex!)
                ? question.explanationCorrect
                : question.explanationWrong}
            </p>
          </div>
        )}

        {/* Action Button */}
        {hasSubmitted ? (
          <button
            type="button"
            onClick={handleContinue}
            className="w-full py-3.5 px-6 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-stone-950 font-bold text-base rounded border border-amber-300 shadow-lg cursor-pointer transition transform active:scale-98 flex items-center justify-center gap-2"
          >
            <span>Teruskan Meneroka Pustaka ➡️</span>
            <span className="text-xs font-mono opacity-80">(Tekan Enter / Spes)</span>
          </button>
        ) : (
          <div className="text-center text-xs text-stone-400 font-mono">
            Pilih satu jawapan (Tekan A, B, C, D atau Klik)
          </div>
        )}
      </div>
    </div>
  );
};
