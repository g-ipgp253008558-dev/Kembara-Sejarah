import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { PlayerScoreRecord } from '../types/game';
import { downloadCSV, copyTSVForSheets, getScoreRecords } from '../utils/sheetsSync';
import { soundManager } from '../utils/audio';

interface GameOverScreenProps {
  record: PlayerScoreRecord;
  onRestart: () => void;
  onOpenLeaderboard: () => void;
}

export const GameOverScreen: React.FC<GameOverScreenProps> = ({
  record,
  onRestart,
  onOpenLeaderboard
}) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Play victory fanfare
    soundManager.playVictory();

    // Trigger celebratory confetti if score >= 3
    if (record.score >= 3) {
      try {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 }
        });
        setTimeout(() => {
          confetti({
            particleCount: 60,
            angle: 60,
            spread: 55,
            origin: { x: 0 }
          });
          confetti({
            particleCount: 60,
            angle: 120,
            spread: 55,
            origin: { x: 1 }
          });
        }, 400);
      } catch {}
    }
  }, [record.score]);

  // Encouraging feedback based on score
  const getFeedbackMessage = () => {
    const s = record.score;
    if (s === 6) {
      return {
        badge: '🏆 CEMERLANG MUTLAK (100%)',
        badgeColor: 'bg-amber-900/60 border-amber-500 text-amber-300',
        quote: 'Tahniah Terulung! Penguasaan anda tentang Sistem Pendidikan Sebelum Merdeka di Tanah Melayu dan dasar pendidikan penjajah British sangat membanggakan!'
      };
    } else if (s >= 4) {
      return {
        badge: '🌟 PENCAPAIAN HEBAT',
        badgeColor: 'bg-emerald-950/70 border-emerald-500 text-emerald-300',
        quote: 'Syabas dan tahniah! Anda memahami dengan jelas perbezaan sekolah vernakular Melayu, Tamil, dan Inggeris pada zaman penjajahan British.'
      };
    } else if (s >= 2) {
      return {
        badge: '👍 USAHA YANG BAIK',
        badgeColor: 'bg-blue-950/70 border-blue-500 text-blue-300',
        quote: 'Usaha yang terpuji! Teliti ringkasan flashback di bawah untuk mengukuhkan pemahaman mengenai pembahagian sistem pendidikan era kolonial.'
      };
    } else {
      return {
        badge: '📚 CUBA LAGI DENGAN SEMANGAT',
        badgeColor: 'bg-rose-950/70 border-rose-600 text-rose-300',
        quote: 'Jangan berputus asa! Sejarah ialah panduan masa depan. Semak fakta jawapan di bawah untuk mengasah ilmu anda dan cuba lagi!'
      };
    }
  };

  const feedback = getFeedbackMessage();

  const handleCopyTSV = async () => {
    soundManager.playClick();
    const allRecords = getScoreRecords();
    const ok = await copyTSVForSheets(allRecords);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2800);
    }
  };

  const handleDownloadCSV = () => {
    soundManager.playClick();
    const allRecords = getScoreRecords();
    downloadCSV(allRecords);
  };

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-3 sm:p-5 bg-stone-950/85 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-3xl bg-stone-900 border-4 border-amber-800 rounded-lg shadow-2xl p-5 sm:p-7 text-stone-100 max-h-[92vh] flex flex-col">
        {/* Minecraft Corner Studs */}
        <div className="absolute -top-2 -left-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-amber-500 border border-amber-950" />
        <div className="absolute -bottom-2 -right-2 w-4 h-4 bg-amber-500 border border-amber-950" />

        {/* Scrollable Container */}
        <div className="overflow-y-auto pr-1 space-y-5">
          {/* Header & Score Presentation */}
          <div className="text-center border-b border-amber-800/60 pb-5">
            <div className="inline-block px-3 py-1 mb-2 bg-stone-950 border border-stone-800 rounded text-stone-300 text-xs font-mono">
              Peserta: <span className="text-amber-400 font-bold">{record.playerName}</span> • Masa: {record.durationSeconds}s
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-amber-300 font-mono tracking-wide">
              PENEROKAAN SEJARAH SELESAI!
            </h1>
            <p className="text-xs text-stone-400 mt-0.5">
              Kuiz: Sistem Pendidikan Sebelum Merdeka (Tanah Melayu)
            </p>

            {/* Score Ring / Block readout */}
            <div className="my-4 flex items-center justify-center gap-4">
              <div className="p-4 px-8 bg-stone-950 border-2 border-amber-600 rounded-lg shadow-inner text-center">
                <div className="text-xs font-mono text-amber-400 uppercase tracking-widest">
                  Skor Anda
                </div>
                <div className="text-4xl sm:text-5xl font-black text-amber-200 font-mono">
                  {record.score} <span className="text-2xl text-stone-500">/ {record.totalQuestions}</span>
                </div>
                <div className="text-sm font-bold text-amber-400 font-mono mt-0.5">
                  {record.percentage}% Ketepatan
                </div>
              </div>
            </div>

            {/* Custom Evaluation Message */}
            <div className={`p-3.5 rounded border max-w-xl mx-auto ${feedback.badgeColor}`}>
              <div className="font-mono text-xs uppercase font-extrabold mb-1">
                {feedback.badge}
              </div>
              <p className="text-sm leading-relaxed italic">
                "{feedback.quote}"
              </p>
            </div>
          </div>

          {/* Flashback: Question & Answer Summary */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-base sm:text-lg font-bold text-amber-200 flex items-center gap-2">
                <span>🔍 Flashback: Ringkasan Soalan & Jawapan</span>
                <span className="text-xs px-2 py-0.5 bg-stone-800 text-stone-300 rounded font-mono">
                  {record.answers.length} Artifak Sejarah
                </span>
              </h2>
            </div>

            <div className="space-y-3">
              {record.answers.map((ans, idx) => (
                <div
                  key={idx}
                  className={`p-3.5 rounded border-2 ${
                    ans.isCorrect
                      ? 'bg-stone-950/70 border-emerald-800/80'
                      : 'bg-stone-950/70 border-rose-900/80'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-amber-400 font-semibold">
                        Soalan {idx + 1}: {ans.objectName}
                      </span>
                      {ans.zoneName && (
                        <span className="text-[10px] px-1.5 py-0.5 bg-stone-800 text-amber-300 rounded font-mono">
                          {ans.zoneName}
                        </span>
                      )}
                    </div>
                    <span
                      className={`text-xs px-2 py-0.5 rounded font-mono font-bold ${
                        ans.isCorrect
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                          : 'bg-rose-950 text-rose-300 border border-rose-700'
                      }`}
                    >
                      {ans.isCorrect ? '✅ BETUL' : '❌ SALAH'}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm font-medium text-stone-200 mb-2">
                    {ans.questionText}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs mb-2">
                    <div className="p-2 bg-stone-900/90 rounded border border-stone-800">
                      <span className="text-stone-400 block text-[10px] uppercase font-mono">
                        Pilihan Anda:
                      </span>
                      <span className={ans.isCorrect ? 'text-emerald-300 font-semibold' : 'text-rose-300 font-semibold line-through'}>
                        {ans.selectedOption}
                      </span>
                    </div>

                    {!ans.isCorrect && (
                      <div className="p-2 bg-stone-900/90 rounded border border-emerald-900/60">
                        <span className="text-emerald-400 block text-[10px] uppercase font-mono">
                          Jawapan Yang Tepat:
                        </span>
                        <span className="text-emerald-300 font-semibold">
                          {ans.correctOption}
                        </span>
                      </div>
                    )}
                  </div>

                  <p className="text-xs text-stone-400 italic bg-stone-900/40 p-2 rounded border border-stone-800/50">
                    💡 <span className="text-stone-300">{ans.explanation}</span>
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Google Sheets / Spreadsheet Sync Actions */}
          <div className="p-4 bg-stone-950 border border-amber-900/60 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-mono uppercase tracking-wider text-amber-400 font-bold flex items-center gap-1.5">
                <span>📊 Pautan & Simpanan Google Sheets:</span>
              </div>
              {copied && (
                <span className="text-xs text-emerald-400 font-mono font-semibold animate-pulse">
                  ✅ Berjaya Disalin ke Papan Keratan!
                </span>
              )}
            </div>
            <p className="text-xs text-stone-400 mb-3">
              Rekod pemain telah disimpan secara automatik. Anda boleh memuat turun CSV untuk dibuka dalam Google Sheets atau menyalin data jadual untuk ditampal (Ctrl+V) terus ke dalam sheet.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={handleDownloadCSV}
                className="py-2.5 px-3.5 bg-stone-800 hover:bg-stone-700 text-stone-100 text-xs font-semibold rounded border border-stone-600 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>📥 Muat Turun CSV (Google Sheets)</span>
              </button>

              <button
                type="button"
                onClick={handleCopyTSV}
                className="py-2.5 px-3.5 bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 text-xs font-semibold rounded border border-amber-700/60 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>📋 Salin Format Google Sheets</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer Action Bar */}
        <div className="border-t border-amber-800/60 pt-4 mt-4 flex flex-col sm:flex-row gap-3">
          <button
            type="button"
            onClick={() => {
              soundManager.playClick();
              onRestart();
            }}
            className="flex-1 py-3 px-6 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-stone-950 font-bold text-sm sm:text-base rounded border border-amber-300 shadow-lg cursor-pointer transition transform active:scale-98 flex items-center justify-center gap-2"
          >
            <span>🔄 Main Semula / Peserta Baru</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundManager.playClick();
              onOpenLeaderboard();
            }}
            className="py-3 px-5 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-600 rounded text-sm font-semibold cursor-pointer transition flex items-center justify-center gap-2"
          >
            <span>🏆 Papan Skor Penuh ({getScoreRecords().length})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
