import React, { useState } from 'react';
import { QuizQuestion } from '../types/game';
import { QUIZ_QUESTIONS } from '../data/quizData';
import { soundManager } from '../utils/audio';

interface GameHUDProps {
  playerName: string;
  completedQuestionIds: number[];
  nearQuestion: QuizQuestion | null;
  isNearCompleted: boolean;
  onInteract: () => void;
  onOpenLeaderboard: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  playerName,
  completedQuestionIds,
  nearQuestion,
  isNearCompleted,
  onInteract,
  onOpenLeaderboard
}) => {
  const [isMuted, setIsMuted] = useState(soundManager.getMuted());
  const [showControlsHint, setShowControlsHint] = useState(false);

  const toggleSound = () => {
    const next = soundManager.toggleMute();
    setIsMuted(next);
  };

  const completedCount = completedQuestionIds.length;
  const totalCount = QUIZ_QUESTIONS.length;

  return (
    <div className="absolute inset-0 z-10 pointer-events-none select-none flex flex-col justify-between p-3 sm:p-4">
      {/* Top Header Row */}
      <div className="flex items-start justify-between gap-3">
        {/* Left Status Cluster: Player Badge & 6 Voxel Slots */}
        <div className="pointer-events-auto flex flex-col gap-1.5">
          {/* Player Name Pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-stone-900/90 border-2 border-amber-800/80 rounded-md shadow-lg backdrop-blur-xs text-xs">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
            <span className="font-mono text-stone-300">Peneroka:</span>
            <span className="font-bold text-amber-200">{playerName}</span>
          </div>

          {/* 6 Object Slots */}
          <div className="flex items-center gap-1.5 p-1.5 bg-stone-900/90 border-2 border-stone-800 rounded-md shadow-lg">
            {QUIZ_QUESTIONS.map((q) => {
              const isDone = completedQuestionIds.includes(q.id);
              return (
                <div
                  key={q.id}
                  title={`${q.objectName} (${isDone ? 'Selesai' : 'Belum Selesai'})`}
                  className={`w-7 h-7 rounded border flex items-center justify-center text-xs transition ${
                    isDone
                      ? 'bg-emerald-950 border-emerald-500 text-emerald-200 shadow-sm'
                      : 'bg-stone-950 border-stone-700 text-stone-500 opacity-70'
                  }`}
                >
                  <span>{isDone ? '✅' : q.objectIcon}</span>
                </div>
              );
            })}
            <div className="px-2 text-xs font-mono font-bold text-amber-300">
              {completedCount}/{totalCount}
            </div>
          </div>
        </div>

        {/* Right Action Icons & Controls */}
        <div className="pointer-events-auto flex items-center gap-2">
          {/* Audio Mute Toggle */}
          <button
            type="button"
            onClick={toggleSound}
            title={isMuted ? 'Nyahbisu Bunyi' : 'Bisu Bunyi'}
            className="w-9 h-9 rounded-md bg-stone-900/90 hover:bg-stone-850 border border-stone-700 text-stone-300 flex items-center justify-center text-sm shadow cursor-pointer transition"
          >
            {isMuted ? '🔇' : '🔊'}
          </button>

          {/* Help Toggle */}
          <button
            type="button"
            onClick={() => setShowControlsHint(!showControlsHint)}
            title="Panduan Kawalan"
            className="w-9 h-9 rounded-md bg-stone-900/90 hover:bg-stone-850 border border-stone-700 text-stone-300 flex items-center justify-center text-sm font-mono font-bold shadow cursor-pointer transition"
          >
            ?
          </button>

          {/* Leaderboard button */}
          <button
            type="button"
            onClick={onOpenLeaderboard}
            title="Papan Skor"
            className="px-2.5 py-1.5 rounded-md bg-stone-900/90 hover:bg-stone-850 border border-amber-700/80 text-amber-300 text-xs font-mono font-bold shadow cursor-pointer transition flex items-center gap-1"
          >
            <span>🏆</span>
            <span className="hidden sm:inline">Papan Skor</span>
          </button>
        </div>
      </div>

      {/* Controls Hint Floating Dropdown */}
      {showControlsHint && (
        <div className="pointer-events-auto absolute top-16 right-4 p-3.5 bg-stone-900/95 border-2 border-stone-700 rounded-lg shadow-xl text-xs text-stone-300 space-y-1.5 max-w-xs animate-in fade-in">
          <div className="font-bold text-amber-300 font-mono mb-1">
            🎮 Kawalan Permainan:
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-stone-400">WASD / Anak Panah</span>
            <span className="font-mono text-stone-200">Gerak Karakter</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-stone-400">Shift</span>
            <span className="font-mono text-stone-200">Lari Laju</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-stone-400">Kekunci [E] / Spes</span>
            <span className="font-mono text-stone-200">Interaksi Objek</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-stone-400">Klik / Seret Tetikus</span>
            <span className="font-mono text-stone-200">Pusing Kamera 360°</span>
          </div>
        </div>
      )}

      {/* Proximity Interaction Callout Banner (Appears when near an object) */}
      {nearQuestion && (
        <div className="pointer-events-auto self-center mb-16 sm:mb-8 animate-bounce">
          <button
            type="button"
            onClick={onInteract}
            className={`px-5 py-3 rounded-lg border-2 shadow-2xl flex items-center gap-3 cursor-pointer transition transform active:scale-95 ${
              isNearCompleted
                ? 'bg-emerald-950/90 border-emerald-500 text-emerald-200'
                : 'bg-stone-900/95 border-amber-500 text-amber-100 ring-4 ring-amber-500/30'
            }`}
          >
            <span className="text-2xl">{nearQuestion.objectIcon}</span>
            <div className="text-left">
              <div className="text-xs font-mono uppercase font-bold text-amber-400 flex items-center gap-1.5">
                <span>{isNearCompleted ? 'Artifak Selesai Dijawab' : 'Tekan [E] atau Klik untuk Jawab:'}</span>
                <span className="text-amber-200 font-semibold">• {nearQuestion.zoneName}</span>
              </div>
              <div className="text-sm font-extrabold text-stone-100">
                {nearQuestion.objectName}
              </div>
            </div>
            <span className="ml-2 px-2 py-1 bg-amber-500 text-stone-950 text-xs font-mono font-black rounded">
              [E]
            </span>
          </button>
        </div>
      )}
    </div>
  );
};
