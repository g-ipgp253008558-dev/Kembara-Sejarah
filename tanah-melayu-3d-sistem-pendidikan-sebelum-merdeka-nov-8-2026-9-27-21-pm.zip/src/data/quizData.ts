import { QuizQuestion } from '../types/game';

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    objectId: 'vernacular_gate',
    objectName: 'Gerbang Notis Sekolah Vernakular',
    objectIcon: '🏫',
    category: 'Konsep Pendidikan Kolonial',
    zoneName: 'Sempadan Desa & Bandar',
    question: 'Apakah maksud sekolah vernakular?',
    options: [
      'A. Sekolah yang mengajar bidang ketenteraan',
      'B. Sekolah mengikut bahasa ibunda kaum',
      'C. Sekolah khas untuk golongan bangsawan',
      'D. Sekolah mengikut tahap umur murid'
    ],
    correctIndex: 1,
    validCorrectIndices: [1],
    explanationCorrect: 'Tepat sekali! Sekolah vernakular ialah sekolah yang menggunakan bahasa ibunda kaum masing-masing (seperti bahasa Melayu, Mandarin, atau Tamil) sebagai bahasa pengantar utama.',
    explanationWrong: 'Kurang tepat. Jawapan yang betul ialah Sekolah mengikut bahasa ibunda kaum (Pilihan B). Setiap kaum dididik mengikut bahasa ibunda dan kurikulum tersendiri.',
    worldPosition: [-12, 1.2, -6],
    description: 'Papan kenyataan kayu kolonial dengan titah undang-undang persekolahan vernakular.'
  },
  {
    id: 2,
    objectId: 'rubber_estate',
    objectName: 'Mangkuk Getah & Lonceng Sekolah Tamil',
    objectIcon: '🌳',
    category: 'Pendidikan Estet',
    zoneName: 'Zon Estet Getah British',
    question: 'Sekolah Tamil pada zaman penjajahan British kebanyakannya ditubuhkan untuk pendidikan anak-anak kaum yang bekerja dalam sektor apa?',
    options: [
      'A. Pentadbiran kerajaan',
      'B. Perlombongan bijih timah',
      'C. Perdagangan antarabangsa',
      'D. Perladangan getah'
    ],
    correctIndex: 3,
    validCorrectIndices: [3],
    explanationCorrect: 'Hebat! Di bawah Ordinan Buruh British 1923, majikan estet getah diwajibkan menyediakan sekolah asas Tamil untuk anak-anak pekerja buruh di ladang getah.',
    explanationWrong: 'Jawapan sebenar ialah Perladangan getah (Pilihan D). Kebanyakan imigran kaum India dibawa masuk oleh British untuk bekerja di ladang-ladang getah.',
    worldPosition: [12, 1.2, -8],
    description: 'Mangkuk susu getah seramik dan loceng tembaga di tepi barisan pokok getah estet.'
  },
  {
    id: 3,
    objectId: 'english_school',
    objectName: 'Menara Loceng Sekolah Inggeris',
    objectIcon: '🏛️',
    category: 'Pendidikan Bandar Kolonial',
    zoneName: 'Zon Bandar Kolonial',
    question: 'Apakah bahasa pengantar utama yang digunakan di sekolah Inggeris?',
    options: [
      'A. Bahasa Melayu',
      'B. Bahasa Mandarin',
      'C. Bahasa Tamil',
      'D. Bahasa Inggeris'
    ],
    correctIndex: 3,
    validCorrectIndices: [3],
    explanationCorrect: 'Tepat sekali! Sekolah Inggeris (seperti Penang Free School, Victoria Institution, dan Anderson School) menggunakan bahasa Inggeris sepenuhnya sebagai bahasa pengantar.',
    explanationWrong: 'Kurang tepat. Jawapan yang betul ialah Bahasa Inggeris (Pilihan D). Sekolah ini ditubuhkan di bandar bagi melatih pegawai tadbir dan kerani kerajaan British.',
    worldPosition: [0, 1.4, -15],
    description: 'Menara loceng batu neo-klasik bertatahkan jata pentadbiran Inggeris di pusat bandar.'
  },
  {
    id: 4,
    objectId: 'malay_school',
    objectName: 'Papan Tulis Sekolah Pondok Melayu',
    objectIcon: '🛖',
    category: 'Pendidikan Luar Bandar',
    zoneName: 'Zon Kampung Melayu Tradisional',
    question: 'Pilih ciri-ciri pendidikan sekolah Melayu pada zaman penjajahan British.',
    options: [
      'A. Memberi pendidikan asas seperti membaca, menulis dan mengira',
      'B. Banyak terdapat di kawasan luar bandar',
      'C. Menggunakan bahasa Melayu sebagai bahasa pengantar',
      'D. Menggunakan bahasa Inggeris sepenuhnya'
    ],
    correctIndex: 0,
    validCorrectIndices: [0, 1, 2], // A, B, and C are all valid traits of Sekolah Melayu
    explanationCorrect: 'Tahniah! Sekolah Melayu zaman British sememangnya memberi kemahiran asas 3M (membaca, menulis, mengira), terletak di luar bandar/kampung, dan menggunakan bahasa Melayu. Hanya pilihan D yang tidak benar kerana bahasa Inggeris dikhaskan untuk sekolah bandar.',
    explanationWrong: 'Pilihan D adalah salah. Sekolah Melayu pada era penjajahan British TIDAK menggunakan bahasa Inggeris. Pihak British mengehadkan pendidikan Melayu kepada asas 3M di kampung agar anak petani kekal sebagai petani.',
    worldPosition: [-14, 1.2, 10],
    description: 'Papan hitam kapur kayu dan bangku kayu jati di anjung rumah panggung Melayu.'
  },
  {
    id: 5,
    objectId: 'urban_clock',
    objectName: 'Tiang Lampu & Jam Perbandaran',
    objectIcon: '🕰️',
    category: 'Taburan Geografi Pendidikan',
    zoneName: 'Zon Pusat Bandar Kolonial',
    question: 'Sekolah Inggeris pada zaman British banyak ditubuhkan di kawasan bandar.',
    options: [
      'Betul',
      'Salah'
    ],
    correctIndex: 0,
    validCorrectIndices: [0],
    explanationCorrect: 'Tepat sekali! Sekolah Inggeris kebanyakannya tertumpu di kawasan bandar-bandar besar seperti Pulau Pinang, Kuala Lumpur, Ipoh, dan Melaka.',
    explanationWrong: 'Jawapan sebenarnya adalah BETUL. Sekolah Inggeris ditubuhkan di bandar kerana pelajarnya terdiri daripada anak-anak bangsawan, pembesar, dan golongan elit bandar.',
    worldPosition: [12, 1.2, 10],
    description: 'Tiang besi hitam lampu gas kolonial di dataran bangunan pentadbiran bandar.'
  },
  {
    id: 6,
    objectId: 'colonial_policy',
    objectName: 'Tugu Warta Dasar Pecah & Perintah',
    objectIcon: '📜',
    category: 'Dasar Pendidikan Kebangsaan',
    zoneName: 'Dataran Perlembagaan Kolonial',
    question: 'Sebelum merdeka, semua kaum di Tanah Melayu menerima pendidikan dalam satu sistem sekolah kebangsaan yang seragam.',
    options: [
      'Betul',
      'Salah'
    ],
    correctIndex: 1,
    validCorrectIndices: [1],
    explanationCorrect: 'Cemerlang! Jawapannya ialah SALAH. Sebelum kemerdekaan, TIADA sistem sekolah kebangsaan seragam. Setiap kaum mempunyai sekolah terasing dengan bahasa dan sukatan sendiri (dasar pecah dan perintah British). Sistem seragam hanya bermula selepas Laporan Razak 1956.',
    explanationWrong: 'Jawapan sebenar ialah SALAH. Sebelum merdeka, sistem pendidikan terpisah mengikut kaum tanpa sukatan seragam. Penyatuan sistem pendidikan hanya digubal menjelang kemerdekaan menerusi Laporan Razak 1956.',
    worldPosition: [0, 1.4, 4],
    description: 'Warta diraja British di atas tiang batu marmar memaparkan pecahan 4 aliran persekolahan.'
  }
];
