import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { VoxelCharacter } from './VoxelCharacter';
import { TanahMelayuWorld } from './TanahMelayuWorld';
import { VoxelQuestItem } from './VoxelQuestItem';
import { QUIZ_QUESTIONS } from '../data/quizData';
import { QuizQuestion } from '../types/game';
import { soundManager } from '../utils/audio';

interface GameCanvasProps {
  completedQuestionIds: number[];
  activeQuestion: QuizQuestion | null;
  onNearObject: (question: QuizQuestion | null, isCompleted: boolean) => void;
  onTriggerInteract: (question: QuizQuestion) => void;
  joystickVector: { x: number; y: number };
  interactRequested: boolean;
  onInteractHandled: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  completedQuestionIds,
  activeQuestion,
  onNearObject,
  onTriggerInteract,
  joystickVector,
  interactRequested,
  onInteractHandled
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // References to preserve state across React renders
  const completedIdsRef = useRef<number[]>(completedQuestionIds);
  completedIdsRef.current = completedQuestionIds;

  const activeQuestionRef = useRef<QuizQuestion | null>(activeQuestion);
  activeQuestionRef.current = activeQuestion;

  const onNearObjectRef = useRef(onNearObject);
  onNearObjectRef.current = onNearObject;

  const onTriggerInteractRef = useRef(onTriggerInteract);
  onTriggerInteractRef.current = onTriggerInteract;

  const joystickRef = useRef(joystickVector);
  joystickRef.current = joystickVector;

  const interactRequestedRef = useRef(interactRequested);
  interactRequestedRef.current = interactRequested;

  const onInteractHandledRef = useRef(onInteractHandled);
  onInteractHandledRef.current = onInteractHandled;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Detect Software WebGL
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    // 2. Renderer Setup
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance'
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    // 3. Scene & Camera (Tropical Tanah Melayu Daylight)
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x7dd3fc); // Sky Blue
    scene.fog = new THREE.Fog(0x7dd3fc, 24, 60);

    const camera = new THREE.PerspectiveCamera(
      55,
      container.clientWidth / container.clientHeight,
      0.1,
      120
    );
    camera.position.set(0, 5, 12);

    // 4. Studio RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 5. Lighting Rig (Warm Tropical Equatorial Sun)
    const hemiLight = new THREE.HemisphereLight(0xbae6fd, 0x3f6212, 0.75);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfffbeb, 1.5);
    sunLight.position.set(14, 24, 14);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 60;
    const d = 26;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0005;
    sunLight.shadow.normalBias = 0.02;
    scene.add(sunLight);

    const fillLight = new THREE.DirectionalLight(0x7dd3fc, 0.4);
    fillLight.position.set(-14, 14, -14);
    scene.add(fillLight);

    // 6. Build Tanah Melayu World (Kampung, Estet, Bandar)
    const world = new TanahMelayuWorld();
    scene.add(world.group);

    // 7. Quest Items (6 Historical Artifacts)
    const questItems: VoxelQuestItem[] = QUIZ_QUESTIONS.map((q) => {
      const item = new VoxelQuestItem(q);
      scene.add(item.group);
      return item;
    });

    // 8. Player Character
    const character = new VoxelCharacter();
    character.group.position.set(0, 0, 5); // Start at central crossroads
    scene.add(character.group);

    // 9. Input State
    const keysDown = new Set<string>();
    const onKeyDown = (e: KeyboardEvent) => {
      // Don't capture keys if typing in an input
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      keysDown.add(e.code);

      if (e.code === 'KeyE' || e.code === 'Space') {
        interactRequestedRef.current = true;
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keysDown.delete(e.code);
    };
    const onBlur = () => {
      keysDown.clear();
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);

    // Mouse camera orbit drag (Right button or left drag in empty space)
    let isDragging = false;
    let prevMouseX = 0;
    let cameraOrbitAngle = 0;

    const onMouseDown = (e: MouseEvent) => {
      if (e.button === 0 || e.button === 2) {
        isDragging = true;
        prevMouseX = e.clientX;
      }
    };
    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - prevMouseX;
      prevMouseX = e.clientX;
      cameraOrbitAngle -= dx * 0.006;
    };
    const onMouseUp = () => {
      isDragging = false;
    };

    const domEl = renderer.domElement;
    domEl.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    // 10. Resize Observer
    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // Pre-warm shaders
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // 11. Main 60fps Loop
    let frameId = 0;
    let lastTime = performance.now();
    const clock = new THREE.Clock();

    // Reusable math helpers
    const _moveDir = new THREE.Vector3();
    const _oldPos = new THREE.Vector3();
    const _cameraTargetPos = new THREE.Vector3();
    const _lookTarget = new THREE.Vector3();

    let currentNearestQuestion: QuizQuestion | null = null;
    let nearestCompleted = false;

    function tick() {
      const now = performance.now();
      const rawDelta = clock.getDelta();
      const delta = Math.min(rawDelta, 0.05); // clamp delta
      lastTime = now;

      // Update completed items state from ref
      const completedSet = new Set(completedIdsRef.current);
      questItems.forEach((item) => {
        item.setCompleted(completedSet.has(item.question.id));
        item.update(delta);
      });

      // Character Movement (Only if not in modal dialog)
      const canMove = !activeQuestionRef.current;
      _moveDir.set(0, 0, 0);

      if (canMove) {
        // Keyboard inputs (WASD & Arrows)
        let kx = 0;
        let kz = 0;
        if (keysDown.has('KeyW') || keysDown.has('ArrowUp')) kz -= 1;
        if (keysDown.has('KeyS') || keysDown.has('ArrowDown')) kz += 1;
        if (keysDown.has('KeyA') || keysDown.has('ArrowLeft')) kx -= 1;
        if (keysDown.has('KeyD') || keysDown.has('ArrowRight')) kx += 1;

        // Joystick inputs
        const joy = joystickRef.current;
        if (Math.abs(joy.x) > 0.05 || Math.abs(joy.y) > 0.05) {
          kx += joy.x;
          kz += joy.y;
        }

        if (kx !== 0 || kz !== 0) {
          // Normalize input vector
          const len = Math.hypot(kx, kz);
          const nx = kx / len;
          const nz = kz / len;

          // Align movement with current camera orbit angle
          const cos = Math.cos(cameraOrbitAngle);
          const sin = Math.sin(cameraOrbitAngle);
          _moveDir.x = nx * cos - nz * sin;
          _moveDir.z = nx * sin + nz * cos;
          _moveDir.normalize();

          // Movement speed
          const isSprint = keysDown.has('ShiftLeft') || keysDown.has('ShiftRight');
          const moveSpeed = isSprint ? 7.2 : 5.0;

          _oldPos.copy(character.group.position);
          const newPos = _oldPos.clone().addScaledVector(_moveDir, moveSpeed * delta);

          // Resolve collisions with terrain obstacles (houses, trees, buildings)
          const resolvedPos = world.checkAndResolveCollision(newPos, _oldPos, 0.45);
          character.group.position.copy(resolvedPos);

          soundManager.playFootstep();
        }
      }

      const isMoving = _moveDir.lengthSq() > 0.01;
      character.update(delta, isMoving, _moveDir);

      // Proximity Detection with 6 Quest Objects
      const playerPos = character.getPosition();
      let nearestDist = Infinity;
      let candidateItem: VoxelQuestItem | null = null;

      for (const item of questItems) {
        const itemPos = item.getPosition();
        const dist = playerPos.distanceTo(itemPos);
        const isNear = dist <= 2.8;
        item.setProximity(isNear);

        if (isNear && dist < nearestDist) {
          nearestDist = dist;
          candidateItem = item;
        }
      }

      // Update HUD Near Object state
      const newlyNearest: QuizQuestion | null = candidateItem ? candidateItem.question : null;
      const isCandidateCompleted: boolean = candidateItem ? candidateItem.isCompleted : false;

      if (newlyNearest !== currentNearestQuestion || isCandidateCompleted !== nearestCompleted) {
        currentNearestQuestion = newlyNearest;
        nearestCompleted = isCandidateCompleted;
        onNearObjectRef.current(currentNearestQuestion, nearestCompleted);
      }

      // Check interaction trigger
      if (interactRequestedRef.current) {
        interactRequestedRef.current = false;
        onInteractHandledRef.current();

        if (candidateItem && !activeQuestionRef.current) {
          soundManager.playInteract();
          onTriggerInteractRef.current(candidateItem.question);
        }
      }

      // Third-Person Camera Follow
      const targetDist = 6.4;
      const targetHeight = 4.0;
      const camX = playerPos.x + Math.sin(cameraOrbitAngle) * targetDist;
      const camZ = playerPos.z + Math.cos(cameraOrbitAngle) * targetDist;
      const camY = playerPos.y + targetHeight;

      _cameraTargetPos.set(camX, camY, camZ);
      camera.position.lerp(_cameraTargetPos, Math.min(1.0, delta * 7.0));

      // Camera looks at chest height of player
      _lookTarget.set(playerPos.x, playerPos.y + 1.2, playerPos.z);
      camera.lookAt(_lookTarget);

      // Render frame
      renderer.render(scene, camera);

      frameId = requestAnimationFrame(tick);
    }

    frameId = requestAnimationFrame(tick);

    // Cleanup
    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      domEl.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('resize', onResize);

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return <div ref={mountRef} className="absolute inset-0 w-full h-full overflow-hidden" />;
};
