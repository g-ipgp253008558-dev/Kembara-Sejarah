import * as THREE from 'three';
import { QuizQuestion } from '../types/game';

export class VoxelQuestItem {
  public group: THREE.Group;
  public question: QuizQuestion;
  public isCompleted: boolean = false;
  public isNearPlayer: boolean = false;

  private objectMeshGroup: THREE.Group;
  private overheadBadgeGroup: THREE.Group;
  private pendingIcon: THREE.Group;
  private completedIcon: THREE.Group;
  private proximityRing: THREE.Mesh;
  private beaconLight: THREE.PointLight;

  private time: number = Math.random() * 10;
  private baseY: number;

  constructor(question: QuizQuestion) {
    this.question = question;
    this.group = new THREE.Group();
    const [x, y, z] = question.worldPosition;
    this.group.position.set(x, 0, z);
    this.baseY = y;

    // Sub-group for model
    this.objectMeshGroup = new THREE.Group();
    this.objectMeshGroup.position.y = this.baseY;
    this.group.add(this.objectMeshGroup);

    // Build the specific colonial 3D voxel model
    this.buildModel(question.objectId);

    // Proximity ground ring
    const ringGeo = new THREE.RingGeometry(1.2, 1.4, 24);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.45,
      side: THREE.DoubleSide,
      depthWrite: false
    });
    this.proximityRing = new THREE.Mesh(ringGeo, ringMat);
    this.proximityRing.rotation.x = -Math.PI / 2;
    this.proximityRing.position.y = 0.03;
    this.group.add(this.proximityRing);

    // Overhead Badge
    this.overheadBadgeGroup = new THREE.Group();
    this.overheadBadgeGroup.position.y = this.baseY + 1.8;

    // 1. Pending Badge (Golden Floating Diamond)
    this.pendingIcon = this.createPendingDiamond();
    this.overheadBadgeGroup.add(this.pendingIcon);

    // 2. Completed Badge (Green Voxel Checkmark)
    this.completedIcon = this.createCompletedCheckmark();
    this.completedIcon.visible = false;
    this.overheadBadgeGroup.add(this.completedIcon);

    this.group.add(this.overheadBadgeGroup);

    // Point Light for dramatic glow
    this.beaconLight = new THREE.PointLight(0xf59e0b, 1.4, 6, 2);
    this.beaconLight.position.y = this.baseY + 1.0;
    this.group.add(this.beaconLight);
  }

  private buildModel(objectId: string) {
    switch (objectId) {
      case 'vernacular_gate':
        this.buildVernacularGate();
        break;
      case 'rubber_estate':
        this.buildRubberEstateItem();
        break;
      case 'english_school':
        this.buildEnglishSchoolItem();
        break;
      case 'malay_school':
        this.buildMalaySchoolItem();
        break;
      case 'urban_clock':
        this.buildUrbanClockItem();
        break;
      case 'colonial_policy':
      default:
        this.buildColonialPolicyItem();
        break;
    }
  }

  // 1. Gerbang Sekolah Vernakular
  private buildVernacularGate() {
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x5c3d1e, roughness: 0.8 });
    const signMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.6 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x854d0e, roughness: 0.7 });

    // Left and right wooden gate posts
    const p1 = new THREE.Mesh(new THREE.BoxGeometry(0.35, 2.2, 0.35), woodMat);
    p1.position.set(-1.0, 0, 0);
    this.objectMeshGroup.add(p1);

    const p2 = new THREE.Mesh(new THREE.BoxGeometry(0.35, 2.2, 0.35), woodMat);
    p2.position.set(1.0, 0, 0);
    this.objectMeshGroup.add(p2);

    // Overhead beam
    const beam = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.3, 0.4), woodMat);
    beam.position.set(0, 1.0, 0);
    this.objectMeshGroup.add(beam);

    // Pitched mini attap roof over gate
    const roof = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.35, 0.7), roofMat);
    roof.position.set(0, 1.3, 0);
    this.objectMeshGroup.add(roof);

    // Signboard: "SEKOLAH VERNAKULAR"
    const sign = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.45, 0.1), signMat);
    sign.position.set(0, 0.65, 0);
    this.objectMeshGroup.add(sign);
  }

  // 2. Mangkuk Susu Getah & Lonceng Sekolah Tamil Estet
  private buildRubberEstateItem() {
    const postMat = new THREE.MeshStandardMaterial({ color: 0x44403c, roughness: 0.8 });
    const brassMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.85, roughness: 0.25 });
    const latexMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.2 });

    // Wooden Stand Post
    const stand = new THREE.Mesh(new THREE.BoxGeometry(0.4, 1.6, 0.4), postMat);
    stand.position.set(0, -0.2, 0);
    this.objectMeshGroup.add(stand);

    // Brass School Bell (Loceng Sekolah Estet)
    const bell = new THREE.Mesh(new THREE.ConeGeometry(0.32, 0.45, 12), brassMat);
    bell.rotation.x = Math.PI;
    bell.position.set(0, 0.7, 0);
    this.objectMeshGroup.add(bell);

    // Bell Clapper
    const clapper = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), brassMat);
    clapper.position.set(0, 0.45, 0);
    this.objectMeshGroup.add(clapper);

    // Rubber Cup with White Latex
    const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.18, 0.3, 10), latexMat);
    cup.position.set(0.6, -0.4, 0);
    this.objectMeshGroup.add(cup);

    // Sheet of cured rubber (Getah Keping)
    const rubberSheetMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.9 });
    const sheet = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.05, 0.7), rubberSheetMat);
    sheet.position.set(-0.5, -0.5, 0);
    this.objectMeshGroup.add(sheet);
  }

  // 3. Menara Loceng Sekolah Inggeris (English School Tower)
  private buildEnglishSchoolItem() {
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.7 });
    const bronzeMat = new THREE.MeshStandardMaterial({ color: 0xb45309, metalness: 0.8, roughness: 0.3 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.7 });

    // Neo-classical Plinth
    const base = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.4, 1.2), stoneMat);
    base.position.set(0, -0.6, 0);
    this.objectMeshGroup.add(base);

    // 4 Corner Stone Columns
    const corners = [[-0.4, -0.4], [0.4, -0.4], [-0.4, 0.4], [0.4, 0.4]];
    corners.forEach(([cx, cz]) => {
      const col = new THREE.Mesh(new THREE.BoxGeometry(0.18, 1.2, 0.18), stoneMat);
      col.position.set(cx, 0.1, cz);
      this.objectMeshGroup.add(col);
    });

    // Hanging Bronze School Bell
    const bell = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.4, 10), bronzeMat);
    bell.rotation.x = Math.PI;
    bell.position.set(0, 0.25, 0);
    this.objectMeshGroup.add(bell);

    // Pyramid Blue Roof on Top
    const roof = new THREE.Mesh(new THREE.ConeGeometry(0.9, 0.6, 4), roofMat);
    roof.rotation.y = Math.PI / 4;
    roof.position.set(0, 0.95, 0);
    this.objectMeshGroup.add(roof);
  }

  // 4. Papan Tulis Sekolah Pondok Melayu
  private buildMalaySchoolItem() {
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x5c3d1e, roughness: 0.8 });
    const slateMat = new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.9 });
    const chalkTextMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 });

    // Blackboard Easel
    const boardFrame = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.0, 0.1), woodMat);
    boardFrame.position.set(0, 0.3, 0);
    this.objectMeshGroup.add(boardFrame);

    const slate = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.85, 0.12), slateMat);
    slate.position.set(0, 0.3, 0);
    this.objectMeshGroup.add(slate);

    // White Chalk writing line (3M: Membaca, Menulis, Mengira)
    const line1 = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.04, 0.13), chalkTextMat);
    line1.position.set(0, 0.5, 0);
    this.objectMeshGroup.add(line1);

    const line2 = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.04, 0.13), chalkTextMat);
    line2.position.set(0, 0.3, 0);
    this.objectMeshGroup.add(line2);

    // Easel Legs
    const l1 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.4, 0.1), woodMat);
    l1.position.set(-0.55, -0.3, 0);
    this.objectMeshGroup.add(l1);

    const l2 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.4, 0.1), woodMat);
    l2.position.set(0.55, -0.3, 0);
    this.objectMeshGroup.add(l2);

    // Wooden School Bench (Bangku Panjang)
    const bench = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.35, 0.4), woodMat);
    bench.position.set(0, -0.65, 0.6);
    this.objectMeshGroup.add(bench);
  }

  // 5. Tiang Lampu & Jam Perbandaran Bandar
  private buildUrbanClockItem() {
    const ironMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9, roughness: 0.2 });
    const brassMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.8, roughness: 0.3 });
    const clockFaceMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfef08a, emissiveIntensity: 0.6 });

    // Base plinth
    const plinth = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.4, 0.8), ironMat);
    plinth.position.set(0, -0.6, 0);
    this.objectMeshGroup.add(plinth);

    // Post
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 1.8, 8), ironMat);
    post.position.set(0, 0.3, 0);
    this.objectMeshGroup.add(post);

    // Double-sided Clock Head
    const clockHousing = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.7, 0.3), brassMat);
    clockHousing.position.set(0, 1.2, 0);
    this.objectMeshGroup.add(clockHousing);

    // Front clock face
    const fClock = new THREE.Mesh(new THREE.CircleGeometry(0.28, 12), clockFaceMat);
    fClock.position.set(0, 1.2, 0.16);
    this.objectMeshGroup.add(fClock);

    // Back clock face
    const bClock = new THREE.Mesh(new THREE.CircleGeometry(0.28, 12), clockFaceMat);
    bClock.rotation.y = Math.PI;
    bClock.position.set(0, 1.2, -0.16);
    this.objectMeshGroup.add(bClock);
  }

  // 6. Tugu Warta Dasar Pecah & Perintah
  private buildColonialPolicyItem() {
    const marbleMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 });
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.85, roughness: 0.25 });
    const parchmentMat = new THREE.MeshStandardMaterial({
      color: 0xfef3c7,
      emissive: 0xfde68a,
      emissiveIntensity: 0.3,
      roughness: 0.7
    });

    // Marble Monument Pillar
    const monument = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.4, 1.0), marbleMat);
    monument.position.set(0, -0.1, 0);
    this.objectMeshGroup.add(monument);

    // Golden Capital
    const cap = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.2, 1.2), goldMat);
    cap.position.set(0, 0.65, 0);
    this.objectMeshGroup.add(cap);

    // Floating Royal Colonial Proclamation Scroll
    const scroll = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.8, 12), parchmentMat);
    scroll.rotation.z = Math.PI / 2;
    scroll.position.set(0, 1.15, 0);
    this.objectMeshGroup.add(scroll);

    // Red Royal Seal
    const sealMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.4 });
    const seal = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), sealMat);
    seal.position.set(0, 1.15, 0.16);
    this.objectMeshGroup.add(seal);
  }

  // Overhead Pending Badge: Golden Diamond + exclamation
  private createPendingDiamond(): THREE.Group {
    const group = new THREE.Group();
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0xd97706,
      emissiveIntensity: 0.5,
      metalness: 0.8,
      roughness: 0.2
    });

    const diamond = new THREE.Mesh(new THREE.OctahedronGeometry(0.24, 0), goldMat);
    group.add(diamond);

    const dot = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.06), goldMat);
    dot.position.y = -0.25;
    group.add(dot);

    return group;
  }

  // Overhead Completed Badge: Emerald Voxel Checkmark
  private createCompletedCheckmark(): THREE.Group {
    const group = new THREE.Group();
    const greenMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      emissive: 0x059669,
      emissiveIntensity: 0.6,
      roughness: 0.3
    });

    const shortArm = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.22, 0.08), greenMat);
    shortArm.rotation.z = Math.PI / 4;
    shortArm.position.set(-0.12, 0.02, 0);
    group.add(shortArm);

    const longArm = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.44, 0.08), greenMat);
    longArm.rotation.z = -Math.PI / 4;
    longArm.position.set(0.08, 0.1, 0);
    group.add(longArm);

    return group;
  }

  public setCompleted(completed: boolean) {
    this.isCompleted = completed;
    this.pendingIcon.visible = !completed;
    this.completedIcon.visible = completed;

    if (completed) {
      this.beaconLight.color.setHex(0x10b981);
      (this.proximityRing.material as THREE.MeshBasicMaterial).color.setHex(0x10b981);
    }
  }

  public setProximity(near: boolean) {
    this.isNearPlayer = near;
    const ringMat = this.proximityRing.material as THREE.MeshBasicMaterial;
    if (near) {
      ringMat.opacity = 0.85;
      this.proximityRing.scale.set(1.15, 1.15, 1.15);
    } else {
      ringMat.opacity = this.isCompleted ? 0.25 : 0.45;
      this.proximityRing.scale.set(1.0, 1.0, 1.0);
    }
  }

  public update(delta: number) {
    this.time += delta;

    // Bobbing & slow rotation of overhead badge
    this.overheadBadgeGroup.position.y = this.baseY + 1.6 + Math.sin(this.time * 3) * 0.12;
    this.overheadBadgeGroup.rotation.y += delta * 1.8;

    // Ambient item subtle rotation / pulse
    if (this.question.objectId === 'colonial_policy') {
      this.objectMeshGroup.rotation.y += delta * 0.5;
    }
  }

  public getPosition(): THREE.Vector3 {
    return this.group.position;
  }
}
