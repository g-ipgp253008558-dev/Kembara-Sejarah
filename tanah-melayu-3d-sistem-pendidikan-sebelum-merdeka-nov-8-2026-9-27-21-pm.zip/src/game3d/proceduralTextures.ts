import * as THREE from 'three';

// Pixel-perfect Minecraft-style textures for Colonial Malaya (Kampung, Estet, Bandar)
export class ProceduralTextures {
  private static setPixelFilter(tex: THREE.CanvasTexture): THREE.CanvasTexture {
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestMipmapNearestFilter;
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.generateMipmaps = true;
    return tex;
  }

  // 1. Tropical Malaya Grass
  public static createGrass(): THREE.CanvasTexture {
    const size = 32;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#4d7c0f'; // rich tropical green
    ctx.fillRect(0, 0, size, size);

    // Pixel shades
    for (let y = 0; y < size; y += 2) {
      for (let x = 0; x < size; x += 2) {
        const rand = Math.random();
        if (rand < 0.25) {
          ctx.fillStyle = '#3f6212'; // darker
        } else if (rand < 0.5) {
          ctx.fillStyle = '#65a30d'; // lighter
        } else {
          ctx.fillStyle = '#4d7c0f';
        }
        ctx.fillRect(x, y, 2, 2);
      }
    }
    return this.setPixelFilter(new THREE.CanvasTexture(canvas));
  }

  // 2. Red Laterite Dirt Road (Jalan Tanah Merah)
  public static createRedLaterite(): THREE.CanvasTexture {
    const size = 32;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#9a3412'; // laterite red-brown
    ctx.fillRect(0, 0, size, size);

    for (let y = 0; y < size; y += 2) {
      for (let x = 0; x < size; x += 2) {
        const rand = Math.random();
        if (rand < 0.25) {
          ctx.fillStyle = '#7c2d12';
        } else if (rand < 0.5) {
          ctx.fillStyle = '#c2410c';
        } else {
          ctx.fillStyle = '#9a3412';
        }
        ctx.fillRect(x, y, 2, 2);
      }
    }
    return this.setPixelFilter(new THREE.CanvasTexture(canvas));
  }

  // 3. Malay Cengal Wood Planks (Rumah Panggung)
  public static createMalayWood(): THREE.CanvasTexture {
    const size = 32;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#5c3d1e';
    ctx.fillRect(0, 0, size, size);

    // Horizontal planks
    for (let i = 0; i < 4; i++) {
      const y = i * 8;
      ctx.fillStyle = i % 2 === 0 ? '#6d4822' : '#543618';
      ctx.fillRect(0, y, size, 7);

      ctx.fillStyle = '#301c0b';
      ctx.fillRect(0, y + 7, size, 1); // seam

      // Vertical seam
      const sx = (i % 2 === 0) ? 16 : 8;
      ctx.fillRect(sx, y, 1, 7);
    }
    return this.setPixelFilter(new THREE.CanvasTexture(canvas));
  }

  // 4. Nipah / Attap Thatched Roof (Bumbung Atap Nipah)
  public static createAttapRoof(): THREE.CanvasTexture {
    const size = 32;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#785938';
    ctx.fillRect(0, 0, size, size);

    for (let row = 0; row < 4; row++) {
      const y = row * 8;
      ctx.fillStyle = row % 2 === 0 ? '#8a6741' : '#6b4d2e';
      ctx.fillRect(0, y, size, 7);

      // Thatch strips
      for (let x = 0; x < size; x += 4) {
        ctx.fillStyle = Math.random() > 0.5 ? '#9c774f' : '#573d23';
        ctx.fillRect(x + (row % 2) * 2, y + 1, 2, 6);
      }

      ctx.fillStyle = '#422c15';
      ctx.fillRect(0, y + 7, size, 1);
    }
    return this.setPixelFilter(new THREE.CanvasTexture(canvas));
  }

  // 5. White British Colonial Wall (Bangunan Kolonial Putih/Kuning)
  public static createColonialWall(): THREE.CanvasTexture {
    const size = 32;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#f8fafc'; // colonial plaster white
    ctx.fillRect(0, 0, size, size);

    // Brick mortar lines
    for (let row = 0; row < 4; row++) {
      const y = row * 8;
      const offset = (row % 2) * 8;
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(0, y + 7, size, 1); // horizontal

      for (let col = 0; col < 2; col++) {
        ctx.fillRect((offset + col * 16) % size, y, 1, 7);
      }
    }
    return this.setPixelFilter(new THREE.CanvasTexture(canvas));
  }

  // 6. Rubber Tree Bark with Tapping Cut (Batang Pokok Getah Bertoreh)
  public static createRubberBark(): THREE.CanvasTexture {
    const size = 32;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#57534e'; // greyish-brown bark
    ctx.fillRect(0, 0, size, size);

    // Bark grain
    for (let i = 0; i < 20; i++) {
      ctx.fillStyle = Math.random() > 0.5 ? '#44403c' : '#78716c';
      const x = Math.floor(Math.random() * size);
      const y = Math.floor(Math.random() * size);
      ctx.fillRect(x, y, 2, 4);
    }

    // Tapping incision line (spiral cut)
    ctx.fillStyle = '#292524';
    for (let i = 0; i < 16; i++) {
      ctx.fillRect(8 + i, 8 + Math.floor(i * 0.7), 2, 2);
    }

    // White latex droplet stream
    ctx.fillStyle = '#fafaf9';
    ctx.fillRect(20, 18, 2, 8);
    ctx.fillRect(21, 26, 3, 3); // collecting cup

    return this.setPixelFilter(new THREE.CanvasTexture(canvas));
  }

  // 7. Colonial Town Cobblestone
  public static createTownCobble(): THREE.CanvasTexture {
    const size = 32;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#64748b';
    ctx.fillRect(0, 0, size, size);

    for (let y = 0; y < size; y += 4) {
      for (let x = 0; x < size; x += 4) {
        ctx.fillStyle = (x + y) % 8 === 0 ? '#475569' : '#94a3b8';
        ctx.fillRect(x + 1, y + 1, 3, 3);
        ctx.fillStyle = '#334155';
        ctx.fillRect(x, y, 1, 4);
        ctx.fillRect(x, y, 4, 1);
      }
    }
    return this.setPixelFilter(new THREE.CanvasTexture(canvas));
  }

  // 8. Character Face: Malay Explorer/Student
  public static createCharacterFace(): THREE.CanvasTexture {
    const size = 32;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    // Skin
    ctx.fillStyle = '#d9a066';
    ctx.fillRect(0, 0, size, size);

    // Black Hair / Songkok edge
    ctx.fillStyle = '#1c1917';
    ctx.fillRect(0, 0, size, 10);
    ctx.fillRect(0, 10, 6, 4);
    ctx.fillRect(size - 6, 10, 6, 4);

    // Eyes
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(6, 15, 6, 4);
    ctx.fillStyle = '#292524';
    ctx.fillRect(8, 15, 4, 4);

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(size - 12, 15, 6, 4);
    ctx.fillStyle = '#292524';
    ctx.fillRect(size - 12, 15, 4, 4);

    // Nose
    ctx.fillStyle = '#c58a52';
    ctx.fillRect(size / 2 - 2, 19, 4, 3);

    // Friendly Smile
    ctx.fillStyle = '#7a3e1d';
    ctx.fillRect(size / 2 - 4, 24, 8, 2);

    return this.setPixelFilter(new THREE.CanvasTexture(canvas));
  }
}
