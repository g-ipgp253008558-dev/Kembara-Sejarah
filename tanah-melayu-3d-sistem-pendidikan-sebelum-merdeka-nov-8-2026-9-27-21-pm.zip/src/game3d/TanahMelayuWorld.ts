import * as THREE from 'three';
import { ProceduralTextures } from './proceduralTextures';

export interface CollisionBox {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export class TanahMelayuWorld {
  public group: THREE.Group;
  public collisionBoxes: CollisionBox[] = [];

  constructor() {
    this.group = new THREE.Group();
    this.buildWorld();
  }

  private buildWorld() {
    const worldWidth = 44;
    const worldLength = 44;

    // 1. Terrain Textures
    const grassTex = ProceduralTextures.createGrass();
    grassTex.wrapS = THREE.RepeatWrapping;
    grassTex.wrapT = THREE.RepeatWrapping;
    grassTex.repeat.set(worldWidth / 2, worldLength / 2);

    const roadTex = ProceduralTextures.createRedLaterite();
    roadTex.wrapS = THREE.RepeatWrapping;
    roadTex.wrapT = THREE.RepeatWrapping;

    const townCobbleTex = ProceduralTextures.createTownCobble();
    townCobbleTex.wrapS = THREE.RepeatWrapping;
    townCobbleTex.wrapT = THREE.RepeatWrapping;
    townCobbleTex.repeat.set(6, 6);

    const malayWoodTex = ProceduralTextures.createMalayWood();
    const attapRoofTex = ProceduralTextures.createAttapRoof();
    const colonialWallTex = ProceduralTextures.createColonialWall();
    const rubberBarkTex = ProceduralTextures.createRubberBark();

    // Materials
    const groundMat = new THREE.MeshStandardMaterial({ map: grassTex, roughness: 0.9 });
    const roadMat = new THREE.MeshStandardMaterial({ map: roadTex, roughness: 0.95 });
    const cobbleMat = new THREE.MeshStandardMaterial({ map: townCobbleTex, roughness: 0.85 });

    // 2. Base Ground
    const groundGeo = new THREE.PlaneGeometry(worldWidth + 12, worldLength + 12);
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.group.add(ground);

    // 3. Red Laterite Roads (Jalan Tanah Merah)
    this.buildRoads(roadMat, cobbleMat);

    // 4. Zon 1: Kampung Melayu Tradisional (South-West)
    this.buildKampungZone(malayWoodTex, attapRoofTex);

    // 5. Zon 2: Estet Getah British (East)
    this.buildEstetZone(rubberBarkTex);

    // 6. Zon 3: Bandar Kolonial British (North)
    this.buildBandarZone(colonialWallTex);

    // 7. Natural Boundary: Perimeter Trees & Fences
    this.buildPerimeterDecorations();
  }

  private buildRoads(roadMat: THREE.Material, cobbleMat: THREE.Material) {
    // Main Laterite Crossroad (connects Kampung, Estet, and Bandar)
    // Central Road (Z-axis from -6 to 18)
    const mainRoad = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 26), roadMat);
    mainRoad.rotation.x = -Math.PI / 2;
    mainRoad.position.set(0, 0.015, 6);
    mainRoad.receiveShadow = true;
    this.group.add(mainRoad);

    // Branch to Kampung (X: 0 to -16, Z = 8)
    const kampungBranch = new THREE.Mesh(new THREE.PlaneGeometry(16, 3.2), roadMat);
    kampungBranch.rotation.x = -Math.PI / 2;
    kampungBranch.position.set(-8, 0.018, 8);
    kampungBranch.receiveShadow = true;
    this.group.add(kampungBranch);

    // Branch to Estet Getah (X: 0 to 16, Z = -6)
    const estetBranch = new THREE.Mesh(new THREE.PlaneGeometry(16, 3.2), roadMat);
    estetBranch.rotation.x = -Math.PI / 2;
    estetBranch.position.set(8, 0.018, -6);
    estetBranch.receiveShadow = true;
    this.group.add(estetBranch);

    // Town Square Cobblestone Paving (Bandar Kolonial)
    const townSquare = new THREE.Mesh(new THREE.PlaneGeometry(18, 14), cobbleMat);
    townSquare.rotation.x = -Math.PI / 2;
    townSquare.position.set(0, 0.02, -14);
    townSquare.receiveShadow = true;
    this.group.add(townSquare);
  }

  // ZON 1: KAMPUNG MELAYU TRADISIONAL
  private buildKampungZone(woodTex: THREE.CanvasTexture, attapTex: THREE.CanvasTexture) {
    const woodMat = new THREE.MeshStandardMaterial({ map: woodTex, roughness: 0.8 });
    const attapMat = new THREE.MeshStandardMaterial({ map: attapTex, roughness: 0.95 });
    const timberStiltMat = new THREE.MeshStandardMaterial({ color: 0x3d2817, roughness: 0.85 });

    // Function to build a traditional Malay stilt house (Rumah Panggung)
    const addMalayHouse = (hx: number, hz: number) => {
      const houseGroup = new THREE.Group();
      houseGroup.position.set(hx, 0, hz);

      // 1. Stilts (Tiang Panggung)
      const stiltOffsets = [
        [-2.0, -1.8], [2.0, -1.8],
        [-2.0, 1.8], [2.0, 1.8],
        [0, -1.8], [0, 1.8]
      ];
      stiltOffsets.forEach(([sx, sz]) => {
        const stilt = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.6, 0.3), timberStiltMat);
        stilt.position.set(sx, 0.8, sz);
        stilt.castShadow = true;
        houseGroup.add(stilt);
      });

      // 2. Main Floor Platform
      const floor = new THREE.Mesh(new THREE.BoxGeometry(4.8, 0.25, 4.2), woodMat);
      floor.position.y = 1.6;
      floor.castShadow = true;
      floor.receiveShadow = true;
      houseGroup.add(floor);

      // 3. Wooden Walls (Rumah Ibu)
      const walls = new THREE.Mesh(new THREE.BoxGeometry(4.4, 2.2, 3.8), woodMat);
      walls.position.y = 2.8;
      walls.castShadow = true;
      houseGroup.add(walls);

      // 4. Peaked Attap Thatched Roof (Bumbung Limas / Rabung Melayu)
      const roofBottom = new THREE.Mesh(new THREE.BoxGeometry(5.2, 0.6, 4.6), attapMat);
      roofBottom.position.y = 4.1;
      roofBottom.castShadow = true;
      houseGroup.add(roofBottom);

      const roofTop = new THREE.Mesh(new THREE.BoxGeometry(4.0, 0.8, 3.4), attapMat);
      roofTop.position.y = 4.7;
      roofTop.castShadow = true;
      houseGroup.add(roofTop);

      const roofRidge = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.5, 1.8), attapMat);
      roofRidge.position.y = 5.3;
      roofRidge.castShadow = true;
      houseGroup.add(roofRidge);

      // 5. Wooden Stairs (Tangga Kayu)
      const stairs = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.8, 1.6), woodMat);
      stairs.position.set(0, 0.8, 2.4);
      stairs.rotation.x = 0.45;
      stairs.castShadow = true;
      houseGroup.add(stairs);

      // Warm pelita / porch lantern
      const lanternMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xf59e0b, emissiveIntensity: 1.2 });
      const lantern = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.35, 0.25), lanternMat);
      lantern.position.set(1.4, 2.2, 2.0);
      houseGroup.add(lantern);

      const light = new THREE.PointLight(0xffedd5, 0.8, 5, 2);
      light.position.set(1.4, 2.0, 2.0);
      houseGroup.add(light);

      this.group.add(houseGroup);

      // Collision box for house
      this.collisionBoxes.push({
        minX: hx - 2.6,
        maxX: hx + 2.6,
        minZ: hz - 2.4,
        maxZ: hz + 2.4
      });
    };

    // 2 Traditional Stilt Houses in Village
    addMalayHouse(-14, 14);
    addMalayHouse(-8, 16);

    // Coconut / Palm Trees in Village
    this.addCoconutTree(-12, 6);
    this.addCoconutTree(-16, 9);
    this.addCoconutTree(-6, 11);
    this.addCoconutTree(-16, 17);

    // Village Wooden Signboard: "KAMPUNG MELAYU"
    this.addWoodenPost(-3, 6, 'KAMPUNG MELAYU');
  }

  // ZON 2: ESTET GETAH BRITISH
  private buildEstetZone(barkTex: THREE.CanvasTexture) {
    const barkMat = new THREE.MeshStandardMaterial({ map: barkTex, roughness: 0.85 });
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.9 });
    const shedMat = new THREE.MeshStandardMaterial({ color: 0x44403c, roughness: 0.8 });
    const roofCorrugatedMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.7 });

    // Rows of Rubber Trees (Pokok Getah)
    const treeCoords = [
      [8, -2], [12, -2], [16, -2],
      [8, -6], [12, -6], [16, -6],
      [8, -10], [12, -10], [16, -10]
    ];

    treeCoords.forEach(([tx, tz]) => {
      const treeGroup = new THREE.Group();
      treeGroup.position.set(tx, 0, tz);

      // Trunk (Voxel Cylinder/Box)
      const trunk = new THREE.Mesh(new THREE.BoxGeometry(0.55, 3.6, 0.55), barkMat);
      trunk.position.y = 1.8;
      trunk.castShadow = true;
      treeGroup.add(trunk);

      // White ceramic latex collection cup (Mangkuk Getah)
      const cupMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.3 });
      const cup = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.22, 0.24), cupMat);
      cup.position.set(0.3, 1.2, 0);
      treeGroup.add(cup);

      // Foliage Canopy (Voxel block cluster)
      const c1 = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.2, 2.4), leafMat);
      c1.position.y = 3.9;
      c1.castShadow = true;
      treeGroup.add(c1);

      const c2 = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.2, 1.6), leafMat);
      c2.position.y = 4.8;
      c2.castShadow = true;
      treeGroup.add(c2);

      this.group.add(treeGroup);

      this.collisionBoxes.push({
        minX: tx - 0.45,
        maxX: tx + 0.45,
        minZ: tz - 0.45,
        maxZ: tz + 0.45
      });
    });

    // Estate Smokehouse / Workers Quarters Shed
    const shedGroup = new THREE.Group();
    shedGroup.position.set(15, 0, 4);

    const shedBase = new THREE.Mesh(new THREE.BoxGeometry(4.2, 2.4, 3.2), shedMat);
    shedBase.position.y = 1.2;
    shedBase.castShadow = true;
    shedGroup.add(shedBase);

    const shedRoof = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.6, 3.6), roofCorrugatedMat);
    shedRoof.position.y = 2.65;
    shedRoof.castShadow = true;
    shedGroup.add(shedRoof);

    this.group.add(shedGroup);

    this.collisionBoxes.push({
      minX: 15 - 2.3,
      maxX: 15 + 2.3,
      minZ: 4 - 1.8,
      maxZ: 4 + 1.8
    });

    // Signboard: "ESTET GETAH"
    this.addWoodenPost(5, -4, 'ESTET GETAH');
  }

  // ZON 3: BANDAR KOLONIAL BRITISH
  private buildBandarZone(wallTex: THREE.CanvasTexture) {
    const wallMat = new THREE.MeshStandardMaterial({ map: wallTex, roughness: 0.8 });
    const stoneTrimMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.7 });
    const blueRoofMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.8 });
    const clockFaceMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfef08a, emissiveIntensity: 0.4 });
    const copperDomeMat = new THREE.MeshStandardMaterial({ color: 0x059669, metalness: 0.6, roughness: 0.3 }); // aged green copper

    // Grand Colonial Government School Building (Maktab / Sekolah Inggeris)
    const schoolGroup = new THREE.Group();
    schoolGroup.position.set(0, 0, -18);

    // Main 2-story Hall
    const mainBuilding = new THREE.Mesh(new THREE.BoxGeometry(14.0, 4.4, 4.8), wallMat);
    mainBuilding.position.y = 2.2;
    mainBuilding.castShadow = true;
    mainBuilding.receiveShadow = true;
    schoolGroup.add(mainBuilding);

    // Classical Columns along front
    for (let cx = -6; cx <= 6; cx += 2.4) {
      const col = new THREE.Mesh(new THREE.BoxGeometry(0.45, 4.4, 0.45), stoneTrimMat);
      col.position.set(cx, 2.2, 2.5);
      col.castShadow = true;
      schoolGroup.add(col);
    }

    // Triangular Pediment / Entablature Front
    const pediment = new THREE.Mesh(new THREE.BoxGeometry(6.4, 1.2, 1.2), stoneTrimMat);
    pediment.position.set(0, 4.8, 2.4);
    schoolGroup.add(pediment);

    // Central Clock Tower (Menara Jam)
    const tower = new THREE.Mesh(new THREE.BoxGeometry(3.2, 4.0, 3.2), wallMat);
    tower.position.set(0, 6.2, 0);
    tower.castShadow = true;
    schoolGroup.add(tower);

    // Clock Face Front
    const clock = new THREE.Mesh(new THREE.CircleGeometry(0.8, 12), clockFaceMat);
    clock.position.set(0, 6.5, 1.62);
    schoolGroup.add(clock);

    // Copper Cupola Dome on top
    const dome = new THREE.Mesh(new THREE.DodecahedronGeometry(1.6, 0), copperDomeMat);
    dome.position.set(0, 9.2, 0);
    schoolGroup.add(dome);

    // Flagpole with colonial flag
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 2.5, 6), stoneTrimMat);
    pole.position.set(0, 11.0, 0);
    schoolGroup.add(pole);

    const flagMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, side: THREE.DoubleSide });
    const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.8), flagMat);
    flag.position.set(0.6, 11.6, 0);
    schoolGroup.add(flag);

    // Hip Roof on Wings
    const leftRoof = new THREE.Mesh(new THREE.BoxGeometry(6.0, 1.2, 5.2), blueRoofMat);
    leftRoof.position.set(-4.5, 4.8, 0);
    schoolGroup.add(leftRoof);

    const rightRoof = new THREE.Mesh(new THREE.BoxGeometry(6.0, 1.2, 5.2), blueRoofMat);
    rightRoof.position.set(4.5, 4.8, 0);
    schoolGroup.add(rightRoof);

    this.group.add(schoolGroup);

    this.collisionBoxes.push({
      minX: -7.5,
      maxX: 7.5,
      minZ: -20.5,
      maxZ: -15.2
    });

    // Colonial Gas Lamp Posts along town square
    this.addColonialLampPost(-6, -9);
    this.addColonialLampPost(6, -9);
    this.addColonialLampPost(-6, -15);
    this.addColonialLampPost(6, -15);

    // Signboard: "BANDAR KOLONIAL"
    this.addWoodenPost(-2, -8, 'BANDAR KOLONIAL');
  }

  // Decorative Elements & Props
  private addCoconutTree(x: number, z: number) {
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c3d1e, roughness: 0.9 });
    const palmMat = new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.8 });

    const treeGroup = new THREE.Group();
    treeGroup.position.set(x, 0, z);

    // Slanted trunk segments
    for (let i = 0; i < 5; i++) {
      const seg = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.9, 0.5), trunkMat);
      seg.position.set(i * 0.1, 0.45 + i * 0.8, 0);
      seg.rotation.z = -0.05 * i;
      seg.castShadow = true;
      treeGroup.add(seg);
    }

    // Palm Fronds (Star-shaped voxel leaves)
    const topY = 4.4;
    const angles = [0, Math.PI / 4, Math.PI / 2, (3 * Math.PI) / 4, Math.PI, (5 * Math.PI) / 4, (3 * Math.PI) / 2, (7 * Math.PI) / 4];
    angles.forEach((ang) => {
      const frond = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.1, 0.5), palmMat);
      frond.rotation.y = ang;
      frond.rotation.z = 0.25;
      frond.position.set(0.4 + Math.cos(ang) * 0.8, topY - 0.2, Math.sin(ang) * 0.8);
      treeGroup.add(frond);
    });

    this.group.add(treeGroup);

    this.collisionBoxes.push({
      minX: x - 0.4,
      maxX: x + 0.4,
      minZ: z - 0.4,
      maxZ: z + 0.4
    });
  }

  private addColonialLampPost(x: number, z: number) {
    const ironMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9, roughness: 0.2 });
    const lanternMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfef08a, emissiveIntensity: 1.2 });

    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 3.2, 8), ironMat);
    pole.position.set(x, 1.6, z);
    pole.castShadow = true;
    this.group.add(pole);

    const lantern = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.55, 0.4), lanternMat);
    lantern.position.set(x, 3.2, z);
    this.group.add(lantern);

    const light = new THREE.PointLight(0xffedd5, 0.9, 6, 2);
    light.position.set(x, 3.2, z);
    this.group.add(light);

    this.collisionBoxes.push({
      minX: x - 0.3,
      maxX: x + 0.3,
      minZ: z - 0.3,
      maxZ: z + 0.3
    });
  }

  private addWoodenPost(x: number, z: number, text: string) {
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x5c3d1e, roughness: 0.8 });
    const boardMat = new THREE.MeshStandardMaterial({ color: 0xfae8b2, roughness: 0.7 });

    const post = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.8, 0.2), woodMat);
    post.position.set(x, 0.9, z);
    this.group.add(post);

    const board = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.5, 0.1), boardMat);
    board.position.set(x, 1.5, z);
    this.group.add(board);
  }

  private buildPerimeterDecorations() {
    // Boundary borders with tropical foliage blocks to keep player within world bounds (-20 to 20)
    const foliageMat = new THREE.MeshStandardMaterial({ color: 0x166534, roughness: 0.9 });

    // Perimeter dense trees
    for (let i = -20; i <= 20; i += 4) {
      // North edge
      const tn = new THREE.Mesh(new THREE.BoxGeometry(3.6, 5.0, 3.0), foliageMat);
      tn.position.set(i, 2.5, -22);
      this.group.add(tn);

      // South edge
      const ts = new THREE.Mesh(new THREE.BoxGeometry(3.6, 5.0, 3.0), foliageMat);
      ts.position.set(i, 2.5, 22);
      this.group.add(ts);

      // West edge
      const tw = new THREE.Mesh(new THREE.BoxGeometry(3.0, 5.0, 3.6), foliageMat);
      tw.position.set(-22, 2.5, i);
      this.group.add(tw);

      // East edge
      const te = new THREE.Mesh(new THREE.BoxGeometry(3.0, 5.0, 3.6), foliageMat);
      te.position.set(22, 2.5, i);
      this.group.add(te);
    }
  }

  // Smooth collision resolution
  public checkAndResolveCollision(pos: THREE.Vector3, oldPos: THREE.Vector3, radius: number = 0.45): THREE.Vector3 {
    // 1. World perimeter bounds (-20 to +20)
    const minBoundX = -20.0 + radius;
    const maxBoundX = 20.0 - radius;
    const minBoundZ = -20.0 + radius;
    const maxBoundZ = 20.0 - radius;

    pos.x = Math.max(minBoundX, Math.min(maxBoundX, pos.x));
    pos.z = Math.max(minBoundZ, Math.min(maxBoundZ, pos.z));

    // 2. Obstacles collision: test X and Z separately for smooth sliding along edges
    for (const box of this.collisionBoxes) {
      const bMinX = box.minX - radius;
      const bMaxX = box.maxX + radius;
      const bMinZ = box.minZ - radius;
      const bMaxZ = box.maxZ + radius;

      if (pos.x >= bMinX && pos.x <= bMaxX && pos.z >= bMinZ && pos.z <= bMaxZ) {
        const canKeepZ = !(oldPos.x >= bMinX && oldPos.x <= bMaxX && pos.z >= bMinZ && pos.z <= bMaxZ);
        const canKeepX = !(pos.x >= bMinX && pos.x <= bMaxX && oldPos.z >= bMinZ && oldPos.z <= bMaxZ);

        if (canKeepZ) {
          pos.x = oldPos.x;
        } else if (canKeepX) {
          pos.z = oldPos.z;
        } else {
          pos.x = oldPos.x;
          pos.z = oldPos.z;
        }
      }
    }

    return pos;
  }
}
