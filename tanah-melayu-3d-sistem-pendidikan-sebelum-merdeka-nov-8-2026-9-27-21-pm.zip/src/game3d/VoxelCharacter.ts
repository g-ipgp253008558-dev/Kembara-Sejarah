import * as THREE from 'three';
import { ProceduralTextures } from './proceduralTextures';

export class VoxelCharacter {
  public group: THREE.Group;
  public headGroup: THREE.Group;
  public torsoGroup: THREE.Group;
  public leftArm: THREE.Group;
  public rightArm: THREE.Group;
  public leftLeg: THREE.Group;
  public rightLeg: THREE.Group;
  
  private shadowMesh: THREE.Mesh;
  private walkTime: number = 0;
  private currentSpeed: number = 0;
  private targetAngle: number = 0;
  private currentAngle: number = 0;

  constructor() {
    this.group = new THREE.Group();

    // Materials
    const faceTex = ProceduralTextures.createCharacterFace();
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xd9a066, roughness: 0.8 });
    const hairMat = new THREE.MeshStandardMaterial({ color: 0x4a2c11, roughness: 0.9 });
    const shirtMat = new THREE.MeshStandardMaterial({ color: 0x1f7a8c, roughness: 0.7 }); // Teal Minecraft Steve-style
    const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.8 }); // Deep Blue
    const bootMat = new THREE.MeshStandardMaterial({ color: 0x3e2723, roughness: 0.9 });
    const beltMat = new THREE.MeshStandardMaterial({ color: 0x2b1d0c, roughness: 0.8 });
    const buckleMat = new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.8, roughness: 0.2 });

    const headMaterials = [
      hairMat, // right
      hairMat, // left
      hairMat, // top
      skinMat, // bottom
      new THREE.MeshStandardMaterial({ map: faceTex, roughness: 0.75 }), // front face
      hairMat  // back
    ];

    // 1. HEAD (0.75 x 0.75 x 0.75)
    this.headGroup = new THREE.Group();
    const headGeo = new THREE.BoxGeometry(0.75, 0.75, 0.75);
    const headMesh = new THREE.Mesh(headGeo, headMaterials);
    headMesh.castShadow = true;
    headMesh.receiveShadow = true;
    headMesh.position.y = 0.375;
    this.headGroup.add(headMesh);

    // Hair accent hat layer (0.78 x 0.35 x 0.78)
    const hairCapGeo = new THREE.BoxGeometry(0.8, 0.38, 0.8);
    const hairCap = new THREE.Mesh(hairCapGeo, hairMat);
    hairCap.position.y = 0.58;
    this.headGroup.add(hairCap);

    this.headGroup.position.y = 1.95; // above torso
    this.group.add(this.headGroup);

    // 2. TORSO (0.8 x 1.0 x 0.45)
    this.torsoGroup = new THREE.Group();
    const torsoGeo = new THREE.BoxGeometry(0.8, 1.0, 0.45);
    const torsoMesh = new THREE.Mesh(torsoGeo, shirtMat);
    torsoMesh.castShadow = true;
    torsoMesh.position.y = 0.5;
    this.torsoGroup.add(torsoMesh);

    // Belt and Buckle
    const beltGeo = new THREE.BoxGeometry(0.82, 0.16, 0.47);
    const beltMesh = new THREE.Mesh(beltGeo, beltMat);
    beltMesh.position.y = 0.12;
    this.torsoGroup.add(beltMesh);

    const buckleGeo = new THREE.BoxGeometry(0.22, 0.18, 0.49);
    const buckleMesh = new THREE.Mesh(buckleGeo, buckleMat);
    buckleMesh.position.y = 0.12;
    this.torsoGroup.add(buckleMesh);

    this.torsoGroup.position.y = 0.95;
    this.group.add(this.torsoGroup);

    // 3. ARMS (Left & Right)
    // Left Arm (pivots from shoulder at y = 1.95)
    this.leftArm = new THREE.Group();
    this.leftArm.position.set(-0.58, 1.9, 0);
    const armGeo = new THREE.BoxGeometry(0.36, 0.95, 0.38);
    const leftArmMesh = new THREE.Mesh(armGeo, shirtMat);
    leftArmMesh.castShadow = true;
    leftArmMesh.position.y = -0.475;
    this.leftArm.add(leftArmMesh);

    // Hand skin cuff
    const handGeo = new THREE.BoxGeometry(0.36, 0.25, 0.38);
    const leftHand = new THREE.Mesh(handGeo, skinMat);
    leftHand.position.y = -0.83;
    this.leftArm.add(leftHand);

    this.group.add(this.leftArm);

    // Right Arm
    this.rightArm = new THREE.Group();
    this.rightArm.position.set(0.58, 1.9, 0);
    const rightArmMesh = new THREE.Mesh(armGeo, shirtMat);
    rightArmMesh.castShadow = true;
    rightArmMesh.position.y = -0.475;
    this.rightArm.add(rightArmMesh);

    const rightHand = new THREE.Mesh(handGeo, skinMat);
    rightHand.position.y = -0.83;
    this.rightArm.add(rightHand);

    this.group.add(this.rightArm);

    // 4. LEGS (Left & Right)
    // Left Leg (pivots from hip at y = 0.95)
    this.leftLeg = new THREE.Group();
    this.leftLeg.position.set(-0.21, 0.95, 0);
    const legGeo = new THREE.BoxGeometry(0.38, 0.95, 0.42);
    const leftLegMesh = new THREE.Mesh(legGeo, pantsMat);
    leftLegMesh.castShadow = true;
    leftLegMesh.position.y = -0.475;
    this.leftLeg.add(leftLegMesh);

    // Boot
    const bootGeo = new THREE.BoxGeometry(0.38, 0.28, 0.44);
    const leftBoot = new THREE.Mesh(bootGeo, bootMat);
    leftBoot.position.y = -0.82;
    this.leftLeg.add(leftBoot);

    this.group.add(this.leftLeg);

    // Right Leg
    this.rightLeg = new THREE.Group();
    this.rightLeg.position.set(0.21, 0.95, 0);
    const rightLegMesh = new THREE.Mesh(legGeo, pantsMat);
    rightLegMesh.castShadow = true;
    rightLegMesh.position.y = -0.475;
    this.rightLeg.add(rightLegMesh);

    const rightBoot = new THREE.Mesh(bootGeo, bootMat);
    rightBoot.position.y = -0.82;
    this.rightLeg.add(rightBoot);

    this.group.add(this.rightLeg);

    // 5. Contact Shadow
    const shadowGeo = new THREE.CircleGeometry(0.65, 16);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.35,
      depthWrite: false
    });
    this.shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    this.shadowMesh.rotation.x = -Math.PI / 2;
    this.shadowMesh.position.y = 0.02;
    this.group.add(this.shadowMesh);
  }

  public update(delta: number, isMoving: boolean, moveDirection: THREE.Vector3) {
    // Rotation smoothing
    if (isMoving && moveDirection.lengthSq() > 0.001) {
      this.targetAngle = Math.atan2(moveDirection.x, moveDirection.z);
      // Smooth angle interpolation
      let diff = this.targetAngle - this.currentAngle;
      while (diff < -Math.PI) diff += Math.PI * 2;
      while (diff > Math.PI) diff -= Math.PI * 2;
      this.currentAngle += diff * Math.min(1.0, delta * 14);
      this.group.rotation.y = this.currentAngle;
    }

    // Walking limbs swing
    const targetSpeed = isMoving ? 1.0 : 0.0;
    this.currentSpeed = THREE.MathUtils.damp(this.currentSpeed, targetSpeed, 10, delta);

    if (this.currentSpeed > 0.01) {
      this.walkTime += delta * 9.0;
      const swingAngle = Math.sin(this.walkTime) * 0.7 * this.currentSpeed;

      // Legs swing in opposite directions
      this.leftLeg.rotation.x = swingAngle;
      this.rightLeg.rotation.x = -swingAngle;

      // Arms swing in opposite phase to legs
      this.leftArm.rotation.x = -swingAngle * 0.8;
      this.rightArm.rotation.x = swingAngle * 0.8;

      // Subtle torso and head bounce
      this.torsoGroup.position.y = 0.95 + Math.abs(Math.sin(this.walkTime * 2)) * 0.06 * this.currentSpeed;
      this.headGroup.position.y = 1.95 + Math.abs(Math.sin(this.walkTime * 2)) * 0.05 * this.currentSpeed;
    } else {
      // Idle return to rest
      this.leftLeg.rotation.x = THREE.MathUtils.damp(this.leftLeg.rotation.x, 0, 10, delta);
      this.rightLeg.rotation.x = THREE.MathUtils.damp(this.rightLeg.rotation.x, 0, 10, delta);
      this.leftArm.rotation.x = THREE.MathUtils.damp(this.leftArm.rotation.x, 0, 10, delta);
      this.rightArm.rotation.x = THREE.MathUtils.damp(this.rightArm.rotation.x, 0, 10, delta);
      this.torsoGroup.position.y = THREE.MathUtils.damp(this.torsoGroup.position.y, 0.95, 10, delta);
      this.headGroup.position.y = THREE.MathUtils.damp(this.headGroup.position.y, 1.95, 10, delta);
    }
  }

  public getPosition(): THREE.Vector3 {
    return this.group.position;
  }
}
